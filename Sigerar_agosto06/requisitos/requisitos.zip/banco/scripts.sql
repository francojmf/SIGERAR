CREATE TABLE PRODUTOS ( 
ID INTEGER NOT NULL, 
NOME VARCHAR(50) NOT NULL, 
DATA DATE DEFAULT CURRENTE DATE NOT NULL, 
PRECO DOUBLE PRECISION ( CHECK PRECO > 0), 
ESTOQUE INTEGER ( CHECK ESTOQUE > 0), 
VALOR COMPUTED BY ( PRECO * ESTOQUE ), 
CONSTRAINT PK_PRODUTOS PRIMARY KEY(ID)
);


create table usuario ( 
cd_usuario integer not null, 
no_usuario varchar (40) not null, 
cd_departamento integer not null, 
no_cargo varchar (40) not null, 
nr_fone varchar (30) not null,
no_email varchar (128) not null,
no_conhecimento varchar (40) not null,
no_login varchar(30) not null,
no_senha varchar(10) not null,
constraint pk_usuario primary key(cd_usuario)
);

alter table usuario add no_login varchar(30) not null;
alter table usuario add no_senha varchar(10) not null;


create table departamento ( 
cd_departamento integer not null, 
no_departamento varchar (40) not null, 
no_observacao varchar (128) not null, 
constraint pk_departamento primary key(cd_departamento)
);
#alter table departamento alter column no_descricao to no_observacao

create table projeto ( 
cd_projeto integer not null, 
no_projeto varchar (40) not null, 
ds_projeto varchar(255) not null,
cd_gerente int not null,
constraint pk_projeto primary key(cd_projeto)
);
alter table projeto add dt_inicio date not null;
alter table projeto drop column dt_fim;
alter table projeto add dt_cancelamento date;


create table risco ( 
cd_risco integer not null, 
mm_descricao blob sub_type 1 not null,
vl_peso integer not null,
constraint pk_risco primary key(cd_risco)
);

create table importancia ( 
cd_importancia integer not null, 
mm_descricao blob sub_type 1 not null,
vl_peso integer not null,
constraint pk_importancia primary key(cd_importancia)
);

create table impacto ( 
cd_impacto integer not null, 
mm_descricao blob sub_type 1 not null,
vl_peso integer not null,
constraint pk_impacto primary key(cd_impacto)
);

create table glossario ( 
cd_glossario integer not null, 
no_glossario varchar (40) not null, 
ds_glossario blob sub_type 1 not null,
dt_inicio date not null,
dt_cancelamento date,
constraint pk_projeto primary key(cd_glossario)
);


create table termo ( 
cd_termo integer not null, 
cd_glossario integer not null, 
no_termo varchar (40) not null, 
ds_termo blob sub_type 1 not null,
constraint pk_termo primary key(cd_termo)
);

create table projeto_glossario ( 
cd_projeto integer not null, 
cd_glossario integer not null, 
constraint pk_projeto_glossario primary key(cd_projeto,cd_glossario)
);

create table versaoreq_controleversao ( 
cd_versao integer not null, 
cd_controleversao integer not null, 
constraint pk_versaoreq_controleversao primary key(cd_vers�o,cd_controleversao)
);

create table projeto_usuario ( 
cd_projeto integer not null, 
cd_usuario integer not null, 
cd_alcada integer not null, 
dt_inicio date not null,
dt_cancelamento date,
constraint pk_projeto_usuario primary key(cd_projeto,cd_usuario,dt_inicio)
);

create table controleversao ( 
cd_controleversao integer not null, 
mm_descricao blob sub_type 1 not null,
tipo_documento varchar (40) not null,
constraint pk_controleversao primary key(cd_controleversao)
);

drop table requisito;

create table requisito (
cd_requisito integer not null primary key,
nr_ordem integer not null,
cd_completo varchar(100) not null,
cd_requisito_pai integer references requisito(cd_requisito),
cd_tipo integer not null references tipo_requisito(cd_tipo),
no_requisito varchar(40) not null,
cd_volatilidade integer not null references volatilidade(cd_volatilidade),
cd_usuario integer not null references usuario(cd_usuario),
cd_projeto integer not null references projeto(cd_projeto)
)

alter table requisito add dt_cancelamento datetime;


create generator gen_cd_requisito;

set term @;

create trigger auto_requisito for requisito
active before insert position 0 as 
declare variable v_completo varchar(100);
declare variable v_ordem int;
begin

	if (new.cd_requisito_pai is null) then begin
		select max(nr_ordem) from requisito where cd_requisito_pai is null and cd_projeto=new.cd_projeto into :v_ordem;
		v_completo = '';
	end
	if (not new.cd_requisito_pai is null) then begin
		select cd_completo, 
		(select max(nr_ordem) from requisito where cd_requisito_pai=r.cd_requisito) 
		from requisito r where cd_requisito = new.cd_requisito_pai and cd_projeto=new.cd_projeto into :v_completo, :v_ordem;
	end

	if (v_ordem is null) then begin
		v_ordem=0;
	end

	v_ordem = v_ordem + 1;
	
	new.nr_ordem = v_ordem;
	
	if (v_completo='') then 
		new.cd_completo = v_ordem;
	if (v_completo<>'') then 
		new.cd_completo = v_completo||'.'||v_ordem;

	new.cd_requisito = gen_id(gen_cd_requisito, 1);
end


@ 


drop trigger auto_requisito@

set term ;@












create trigger auto_versao_requisito for versao_requisito
active before insert position 0 as 
declare variable v_versao int;
begin

	if (new.cd_requisito is null) then
		EXCEPTION SEM_REQUISITO;
	
	select max(cd_versao) from versao_requisito where cd_requisito=new.cd_requisito into :v_versao;

	if (v_versao is null) then 
		v_versao=0; 
	
	v_versao = v_versao + 1;
	
	new.cd_versao = v_versao;
end
@ 





create table versao_requisito ( 
cd_versao integer not null, 
cd_requisito integer not null, 
no_versao varchar (40) not null,
dt_solicitacao date not null,
cd_usuario_solicitante integer not null, 
cd_usuario_responsavel integer not null, 
mm_descricao blob sub_type 1 not null,
prioridade varchar (40) not null, 
custo varchar (40) not null,
cd_motivo integer not null, 
cd_risco integer not null, 
cd_importancia integer not null, 
cd_impacto integer not null, 
cd_situacao integer not null, 
constraint pk_versaoreq primary key(cd_versao,cd_requisito)
);


alter table projeto_usuario add dt_inicio date not null, add dt_cancelamento date;

create table alcada (
        cd_alcada integer not null,
        no_alcada varchar (40) not null,
        st_interno smallint not null,
        constraint pk_alcada primary key(cd_alcada)
);
insert into alcada (cd_alcada, no_alcada, st_interno) values (1, 'Gerente', 1);
insert into alcada (cd_alcada, no_alcada, st_interno) values (2, 'Administrador', 1);
insert into alcada (cd_alcada, no_alcada, st_interno) values (3, 'Analista Respons�vel', 0);
insert into alcada (cd_alcada, no_alcada, st_interno) values (4, 'Analista', 0);
insert into alcada (cd_alcada, no_alcada, st_interno) values (5, 'Usu�rio Respons�vel', 0);
insert into alcada (cd_alcada, no_alcada, st_interno) values (6, 'Usu�rio', 0);

create table alcada_permissao ( 
cd_alcada integer not null, 
cd_permissao varchar(20) not null, 
constraint pk_alcada_permissao primary key(cd_alcada,cd_permissao)
);


ALTER TABLE DATI ADD CONSTRAINT DATI FOREIGN KEY (DATI) REFERENCES ANAG(DATI) ON UPDATE CASCADE;
ALTER TABLE DATI ADD CONSTRAINT ID_ FOREIGN KEY (ID) REFERENCES ANAG(ID) ON DELETE CASCADE; 

alter table departamento alter column no_descricao to no_observacao

alter table versaoreq alter column no_versao to cd_controleversao

select g.cd_glossario, g.no_glossario
from projeto_glossario pg, glossario g
where pg.cd_glossario = g.cd_glossario
and pg.cd_projeto=9




create table requisito_dependente ( 
cd_requisito integer not null, 
cd_requisito_superior integer not null, 
primary key (cd_requisito,cd_requisito_superior)
);

create table projeto_glossario ( 
cd_projeto integer not null, 
cd_glossario integer not null, 
constraint pk_projeto_glossario primary key(cd_projeto,cd_glossario)
);

alter table projeto_usuario
add constraint fk_cd_usuario foreign key (cd_usuario) references usuario(cd_usuario)
add constraint fk_cd_projeto foreign key (cd_projeto) references projeto(cd_projeto)




alter table motivo
add st_padrao smallint default 0;




create table alteracao_versao (
	cd_alteracao int not null primary key,
	cd_requisito int not null references requisito (cd_requisito),
	cd_versao int not null,
	cd_versao_anterior int not null,
	vl_custo_total decimal(10,3)
)

create table alteracao_versao_dependente (
	cd_alteracao int not null references alteracao_versao (cd_alteracao),
	cd_requisito int not null references requisito (cd_requisito),
	cd_versao int not null,
	cd_versao_anterior int not null
)




create generator gen_cd_alteracao;
set generator gen_cd_alteracao to 0;


create trigger auto_alteracao_versao for alteracao_versao
active before insert position 0 as 
begin
	new.cd_alteracao = gen_id(gen_cd_alteracao, 1);
end
@ 



alter table alteracao_versao_dependente
drop CD_VERSAO, drop CD_VERSAO_ANTERIOR


alter table alteracao_versao add
CD_VERSAO INTEGER,
add CD_VERSAO_ANTERIOR INTEGER,
add VL_CUSTO_TOTAL DECIMAL(10, 3)

alter table alteracao_versao_dependente add
CD_VERSAO INTEGER,
add CD_VERSAO_ANTERIOR INTEGER






create table mensagem (
	cd_mensagem int not null primary key,
	dh_envio timestamp,
	cd_usuario_remetente int not null references usuario(cd_usuario),
	no_assunto varchar(200) not null,
	mm_mensagem blob sub_type 1 not null,
	cd_usuario_destinatario int references usuario(cd_usuario),
	dh_leitura timestamp,
	st_apagado_remetente smallint default 0,
	st_apagado_destinatario smallint default 0
)

create table mensagem_requisito (
	cd_mensagem int not null primary key references mensagem(cd_mensagem),
	cd_requisito int references requisito(cd_requisito),
	cd_usuario_destinatario int references usuario(cd_usuario),
	st_lido int not null
)


create generator gen_cd_mensagem;
set generator gen_cd_mensagem to 0;

create trigger auto_mensagem for mensagem
active before insert position 0 as 
begin
	new.cd_mensagem = gen_id(gen_cd_mensagem, 1);
end
@ 




drop table mensagem;

create table mensagem (
	cd_mensagem int not null primary key,
	dh_envio timestamp,
	cd_usuario_remetente int references usuario(cd_usuario),
	cd_requisito_remetente int references requisito(cd_requisito),
	cd_usuario_destinatario int references usuario(cd_usuario),
	cd_requisito_destinatario int references requisito(cd_requisito),
	no_assunto varchar(200) not null,
	mm_mensagem blob sub_type 1 not null,
	dh_leitura timestamp,
	st_apagado_remetente smallint default 0,
	st_apagado_destinatario smallint default 0
)





create generator gen_cd_mensagem;
set generator gen_cd_mensagem to 0;

create trigger auto_mensagem for mensagem
active before insert position 0 as 
begin

	if (new.cd_usuario_destinatario is null and new.cd_requisito_destinatario is null) then
		exception EXC_MENSAGEM_FALTA_REMETENTE;
		
	if (new.cd_usuario_destinatario is null and new.cd_requisito_destinatario is null) then
		exception EXC_MENSAGEM_FALTA_REMETENTE;
		

	new.cd_mensagem = gen_id(gen_cd_mensagem, 1);
	
end
@ 


drop exception EXC_MENSAGEM_FALTA_REMETENTE;
drop exception EXC_MENSAGEM_FALTA_DESTINATARIO;


create exception EXC_MENSAGEM_FALTA_REMETENTE 'E necessario um remetente para a mensagem';
create exception EXC_MENSAGEM_FALTA_DESTINATARIO 'E necessario um destinatario para a mensagem';




create table mensagem_forum (
	cd_mensagem int not null primary key,
	cd_alteracao int references alteracao_versao(cd_alteracao),
	dh_envio timestamp,
	cd_usuario int references usuario(cd_usuario),
	no_assunto varchar(200) not null,
	mm_mensagem blob sub_type 1 not null
);

create generator gen_cd_mensagem_forum;
set generator gen_cd_mensagem_forum to 0;

create trigger auto_mensagem_forum for mensagem_forum
active before insert position 0 as 
begin

	new.cd_mensagem = gen_id(gen_cd_mensagem_forum, 1);
	
end
@ 




create table ajuda (

	cd_ajuda varchar(30) not null primary key,
	mm_ajuda blob sub_type 1 not null

)





alter table usuario add constraint fk_cd_departamento  foreign key(cd_departamento) references departamento(cd_departamento);

alter table versao_requisito add constraint fk_cd_usuario_solicitante  foreign key(cd_usuario_solicitante) references usuario(cd_usuario);



alter table versao_requisito add constraint fk_cd_usuario_responsavel  foreign key(cd_usuario_responsavel) references usuario(cd_usuario);


alter table versao_requisito add constraint fk_cd_requisito  foreign key(cd_requisito) references requisito(cd_requisito);

alter table versao_requisito add constraint fk_cd_motico  foreign key(cd_motivo) references motivo(cd_motivo);

alter table versao_requisito add constraint fk_cd_risco  foreign key(cd_risco) references risco(cd_risco);



alter table versao_requisito add constraint fk_cd_importancia  foreign key(cd_importancia) references importancia(cd_importancia);

alter table versao_requisito add constraint fk_cd_impacto  foreign key(cd_impacto) references impacto(cd_impacto);

alter table versao_requisito add constraint fk_cd_situacao  foreign key(cd_situacao) references situacao(cd_situacao);





alter table usuario add ST_ADMIN smallint default 0;



drop table tipo_documento;
create table tipo_documento (
	cd_tipo_documento int not null primary key,
	no_tipo varchar(100)
)


drop table documento_versao;


create table documento_versao (
	cd_documento int not null primary key,
	cd_requisito int not null,
	cd_versao int not null,
	no_documento varchar(200) not null,
	no_localizacao varchar(200) not null,
	cd_tipo_documento int not null
)
alter table documento_versao add constraint fk_tipo  foreign key (cd_tipo_documento) references tipo_documento(cd_tipo_documento);

// n�o consegui:
alter table documento_versao add constraint fk_versao_requisito
	foreign key (cd_requisito, cd_versao) references versao_requisito(cd_requisito,cd_versao)


