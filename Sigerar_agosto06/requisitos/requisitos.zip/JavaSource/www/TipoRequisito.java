package www;

import java.sql.ResultSet;
import java.util.ArrayList;

public class TipoRequisito {
	
	private int id;
	private String nome = "";
	private String descricao = "";
	
	
	public TipoRequisito() {
	}
	
	
	
	public void cadastrar() throws Exception {
		Database database = new Database();
		try {
			
			String SQL;
			
			int newId=0;
			SQL = "select max(cd_tipo) from tipo_requisito";
			ResultSet rs = database.stmt.executeQuery( SQL );
			if (rs.next()) {
				
				System.out.println( "ultimoid " + rs.getInt(1));
				
				newId = rs.getInt(1);
			}                        
			newId++;
			
			SQL =   "INSERT INTO tipo_requisito (cd_tipo, no_tipo, mm_descricao) VALUES (" + newId + ",'"+
			getNome() + "','"+ getDescricao() + "')";
			
			System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar tipo de requisitos!");
		}
		database.fechar();
	}
	
	
	
	
	public void alterar() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL = "update tipo_requisito set no_tipo='"+
			getNome() + "',mm_descricao='"+getDescricao() + "'  where cd_tipo=" + getId();
			
			//System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar tipo dos requisitos!");
		}
		database.fechar();
	}
	
	public void excluir() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL = "delete from tipo_requisito where cd_tipo=" + getId();
			
			//                        System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar tipo dos requisitos!");
		}
		database.fechar();
	}
	
	
	public static ArrayList buscaTipos(String trecho_nome, Pager pager) {
		
		String SQL =
			" FROM tipo_requisito WHERE no_tipo LIKE '%"+
			trecho_nome + "%' ";
		ArrayList retorno = new ArrayList();
		
		
		
		
		Database database = new Database();
		try {
			   int count = 0;
			   ResultSet rs = database.stmt.executeQuery("SELECT count(*) "+SQL);
			   while (rs.next()) {
			    count = rs.getInt(1);
			   }
			   
			   pager.setTotal(count);

			   rs = database.stmt.executeQuery( pager.formatSql("SELECT cd_tipo "+SQL+" ORDER BY no_tipo") );
			while (rs.next()) {
				TipoRequisito tr = new TipoRequisito();
				tr.buscar(rs.getInt("cd_tipo"));
				retorno.add(tr);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	
	public void buscar(int cd) {
		String tempCD;
		tempCD = Integer.toString(cd);
		String SQL = "SELECT * FROM tipo_requisito WHERE cd_tipo="+tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(cd);
				setNome(rs.getString("no_tipo"));
				setDescricao( rs.getString("mm_descricao") );
			}
			//System.out.println("fim");
		}
		catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	public static ArrayList listarTodos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_tipo FROM tipo_requisito ORDER BY no_tipo";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				A.add(new Integer(rs.getInt("cd_tipo")));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	public static String getHtmlCombo(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		String SQL = "SELECT cd_tipo, no_tipo FROM tipo_requisito ORDER BY no_tipo";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {                                
				html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return html.toString();
		
	}      
	
	
	
	/**
	 * @return Returns the descricao.
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao The descricao to set.
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the nome.
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome The nome to set.
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
}