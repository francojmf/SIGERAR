package www;

public class RequisitoMensagem extends Requisito {

	
	int qtde;

	public int getQtde() {
		return qtde;
	}

	public void setQtde(int qtde) {
		this.qtde = qtde;
	}
	
	
	
	
	
}
