/*
 * Created on 21/09/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package www;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author marcelo
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MensagemForum {

	int id;
	Date envio;
	String assunto;
	String mensagem;
	Usuario remetente;
	AlteracaoVersao alteracao;
	
	
	
	
	public static ArrayList listarMensagens( AlteracaoVersao alteracao, Pager p ) {
		
		ArrayList lista= new ArrayList();
		
		
		Database database = new Database();
		try {
			
			String sql = "from mensagem_forum where cd_alteracao=" + alteracao.getId();

			ResultSet rs = database.stmt.executeQuery("select count(*) " +  sql);
			
			while (rs.next()) {
				
				p.setTotal( rs.getInt(1) );
				
			}

			sql = "select * " +
				sql +
				" order by dh_envio desc ";

			rs = database.stmt.executeQuery( p.formatSql(sql) );
			
			while (rs.next()) {

				MensagemForum m = new MensagemForum();

				m.preencher(rs);
				m.setAlteracao(alteracao);
		
				lista.add(m);
			}

		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return lista;
		
		
	}
	
	
	
	
	
	public static MensagemForum getMensagem( int idm ) {
		
		MensagemForum mensagem = null;
		
		
		Database database = new Database();
		try {
			
			String sql = "select * " +
				" from " +
				"mensagem_forum where cd_mensagem=?";
			
			PreparedStatement pstmt = database.conn.prepareStatement( sql );
			
			pstmt.setInt( 1, idm );
			
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
	
				mensagem = new MensagemForum();

				mensagem.preencher( rs );
				
			}
	
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return mensagem;
		
		
	}

	
	void preencher( ResultSet rs ) throws SQLException {
		
		setId( rs.getInt("cd_mensagem") );
		setEnvio( rs.getTimestamp("dh_envio") );

		Usuario remetente = new Usuario();
		remetente.buscar( rs.getInt("cd_usuario") );
		setRemetente( remetente );
		
		setAssunto( rs.getString("no_assunto") );
		setMensagem( rs.getString("mm_mensagem") );
	}

	
	
	



	public void gravar() {
		
		
		Database database = new Database();
		try {
			
			String sql = "insert into MENSAGEM_forum (" +
					"CD_ALTERACAO, DH_ENVIO, CD_USUARIO, NO_ASSUNTO, MM_MENSAGEM" +
					") values (?,?,?,?,?)";

			PreparedStatement pstmt = database.conn.prepareStatement( sql );
			
			pstmt.setInt( 1, getAlteracao().getId() );
			pstmt.setTimestamp(2, getEnvio()==null? null : new Timestamp(getEnvio().getTime()) );
			
			
			pstmt.setInt( 3, getRemetente().getId() );

			pstmt.setString( 4, getAssunto() );
			pstmt.setString( 5, getMensagem() );
			
			pstmt.executeUpdate();
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
	}





	public AlteracaoVersao getAlteracao() {
		return alteracao;
	}





	public void setAlteracao(AlteracaoVersao alteracao) {
		this.alteracao = alteracao;
	}





	public String getAssunto() {
		return assunto;
	}





	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}





	public Date getEnvio() {
		return envio;
	}





	public void setEnvio(Date envio) {
		this.envio = envio;
	}





	public int getId() {
		return id;
	}





	public void setId(int id) {
		this.id = id;
	}





	public String getMensagem() {
		return mensagem;
	}





	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}





	public Usuario getRemetente() {
		return remetente;
	}





	public void setRemetente(Usuario remetente) {
		this.remetente = remetente;
	}

	
	
	

}
