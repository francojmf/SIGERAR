package www;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Util {        
	
	static SimpleDateFormat dateFormat;
	static SimpleDateFormat dateTimeFormat;
	static DecimalFormat decimalFormat;
	
	static {
		dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm");
        decimalFormat = new DecimalFormat();
        decimalFormat.applyPattern("###,###,##0.00");
	}

	public static boolean dataValida( String data ) {

		boolean retorno = false;
		
		try {
			Calendar cal = Calendar.getInstance();

			cal.set(Calendar.DATE, Integer.parseInt(data.substring(0,2)));
			cal.set(Calendar.MONTH, Integer.parseInt(data.substring(3,5))-1);
			cal.set(Calendar.YEAR, Integer.parseInt(data.substring(6,10)));

			retorno = (  strZero(cal.get(Calendar.DATE),2)+"/"+strZero(cal.get(Calendar.MONTH)+1,2)+"/"+cal.get(Calendar.YEAR)  ).equals(data);

		} catch (Exception e) {
			retorno = false;
		}
		
		return retorno;
		
	}
       


	public static String strZero(int numero, int length) {

		return strZero(""+numero, length);

	}


	public static String strZero(String retorno, int length) {

		while (retorno.length()<length) {
			retorno = "0"+retorno;
		}

		return retorno;

	}

		/*
        // 10/10/2002
        public static String dataNormalParaBanco(String data) throws Exception {
                return data.substring(6,10)+"-"+data.substring(3,5)+"-"+data.substring(0,2);
        }
        
        // 2002-12-31
        public static String dataBancoParaNormal(String data) throws Exception {
                return data.substring(8,10)+"/"+data.substring(5,7)+"/"+data.substring(0,4);
        }
        */

        
        // 2002-12-31
        public static String textoParaHtml(String texto) throws Exception {
                
            texto = replace( texto, "\r\n", "<BR>" );
                
                return texto;
        }
        

        
	public static String replace (String oldString, String textA, String textB) {
		StringBuffer newString = new StringBuffer();
		int i = 0;
		for ( ; ; ) {
			if ( (oldString.length() - i) < textA.length() ) {

				newString.append(oldString.substring(i,oldString.length()));
				break;
			} else {
				String fragmento = oldString.substring(i,i+textA.length());
				if (fragmento.equals(textA)) {
					newString.append(textB);
					i = i + textA.length();
				} else {
					newString.append(oldString.substring(i,i+1));
					i++;
				}
			}
		}
		return newString.toString();
	}
        
        
        
        public static String hoje()  {
                return calendarParaData( Calendar.getInstance() );
        }

                
        public static String calendarParaData( Calendar cal )  {
                return strZero(cal.get(Calendar.DATE),2)+"/"+strZero(cal.get(Calendar.MONTH)+1,2)+"/"+cal.get(Calendar.YEAR);
        }


        
        
	/**
	 * @return Returns the dateFormat.
	 */
	public static SimpleDateFormat getDateFormat() {
		return dateFormat;
	}
	
	public static SimpleDateFormat getDateTimeFormat() {
		return dateTimeFormat;
	}



	public static DecimalFormat getDecimalFormat() {
		return decimalFormat;
	}
	
	
	
}