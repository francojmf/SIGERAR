package www;

import java.sql.*;
import java.util.*;

public class Departamento {
	private int id;
	private String nome="";
	private String descricao="";
	
	
	public Departamento() {
	}
	public void cadastrar() {
		
		Database database = new Database();
		
		try {
			String SQL;
			
			int newId=0;
			SQL = "select max(cd_departamento) from departamento";
			ResultSet rs = database.stmt.executeQuery( SQL );
			if (rs.next()) {                              
				System.out.println( "ultimoid " + rs.getInt(1));
				newId = rs.getInt(1);
			}
			
			newId++;                        
			SQL = 
				"INSERT INTO departamento (cd_departamento, no_departamento, no_descricao) VALUES (" + newId + ",'"+          
				getNome() + "','" + getDescricao() + "')";
			
			System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	public static ArrayList buscaDepartamentos(String trecho_nome, Pager pager) {
		String SQL =
			" FROM departamento WHERE no_departamento LIKE '%"+
			trecho_nome + "%'";
		ArrayList retorno = new ArrayList();
		Database database = new Database();
		
		try {
			   int count = 0;
			   ResultSet rs = database.stmt.executeQuery("SELECT count(*) "+SQL);
			   while (rs.next()) {
			    count = rs.getInt(1);
			   }
			   
			   pager.setTotal(count);

			   rs = database.stmt.executeQuery( pager.formatSql("SELECT cd_departamento "+SQL+" ORDER BY no_departamento") );
			while (rs.next()) {
				Departamento d = new Departamento();
				d.buscar(rs.getInt("cd_departamento"));
				retorno.add(d);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	public void buscar(int cd) {
		String tempCD;
		tempCD = Integer.toString(cd);
		String SQL = "SELECT * FROM departamento WHERE cd_departamento="+tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(cd);
				setNome(rs.getString("no_departamento"));
				setDescricao(rs.getString("no_descricao"));
				
			}
			//System.out.println("fim");
		}
		catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	public static ArrayList listarTodos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_departamento FROM departamento ORDER BY departamento";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				A.add(rs.getObject("cd_departamento"));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	public static String getHtmlCombo(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		String SQL = "SELECT cd_departamento, no_departamento FROM departamento ORDER BY no_departamento";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				
				html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		
		return html.toString();
		
	}
	
	public void excluir() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL = "delete from departamento where cd_departamento=" + getId() ;
			//                        System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar departamento!");
		}
		database.fechar();
	}
	
	
	public void alterar() {
		String SQL =   "UPDATE departamento set "+
		"no_departamento='" + getNome() + "',no_descricao='"+getDescricao() + "' where " +
		"cd_departamento=" + getId();
		
		System.out.println(SQL);
		Database database = new Database();
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	
	/**
	 * @return Returns the nome.
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome The nome to set.
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
}