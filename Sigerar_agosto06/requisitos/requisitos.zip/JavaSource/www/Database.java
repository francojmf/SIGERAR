package www;

import java.sql.*;

public class Database {
  public Connection conn;
  public Statement stmt;

  public Database() {
    try {
    	
        Class.forName("org.firebirdsql.jdbc.FBDriver");
        conn = DriverManager.getConnection("jdbc:firebirdsql:localhost/3050:sigerar.fdb?lc_ctype=WIN1252","sysdba","masterkey");
        stmt = conn.createStatement();
         
    } catch (java.lang.Exception erro) {
      erro.printStackTrace();
    }
  }

  public void fechar() {
    try {
    	stmt.close();
    	conn.close();
    	
    	stmt=null;
    	conn=null;
    } catch(java.lang.Exception erro) {
      erro.printStackTrace();
    }
  }
  
  public static void main(String[] str) {
	  
	  Database database = new Database();
	  System.out.println(database.conn);
	  System.out.println(database.stmt);
	  database.fechar();
	  
  }
  
  
}
