package www;

import java.sql.ResultSet;
import java.util.ArrayList;

public class Ajuda {
	
	private String id="";
	private String idOriginal="";
	private String descricao = "";
	private String titulo = "";
	
	
	public void cadastrar() throws Exception {
		Database database = new Database();
		try {
			
			String SQL;
			
			SQL =   "INSERT INTO ajuda (cd_ajuda, mm_ajuda, no_titulo) VALUES ('" + getId() + "','"+
			getDescricao() + "','"+getTitulo()+"')";
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			
			erro.printStackTrace();
			
			if (erro.getMessage().indexOf( "PRIMARY" )>-1) 
				throw new Exception("Já existe uma ajuda com este nome!");
			else
				throw new Exception("Problemas ao cadastrar ajuda!");
		}
		database.fechar();
	}
	
	
	
	
	public void alterar() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL = "update ajuda set cd_ajuda='"+
			getId() + "',mm_ajuda='"+getDescricao() + "',no_titulo='"+getTitulo() + "' " +
					"where cd_ajuda='" + getIdOriginal()+"'";
			
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar ajuda!");
		}
		database.fechar();
	}
	
	public void excluir() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL = "delete from ajuda where cd_ajuda='" + getIdOriginal() + "'";
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar tipo dos requisitos!");
		}
		database.fechar();
	}
	
	
	public static ArrayList buscaAjudas(String trecho_nome, Pager pager) {
		
		String SQL =
			" FROM ajuda WHERE mm_ajuda LIKE '%"+
			trecho_nome + "%' or cd_ajuda like '%"+
			trecho_nome + "%'";
		ArrayList retorno = new ArrayList();
		
		
		
		
		Database database = new Database();
		try {
			   int count = 0;
			   ResultSet rs = database.stmt.executeQuery("SELECT count(*) "+SQL);
			   while (rs.next()) {
			    count = rs.getInt(1);
			   }
			   
			   pager.setTotal(count);

			   rs = database.stmt.executeQuery( pager.formatSql("SELECT * "+SQL+" ORDER BY cd_ajuda") );
			while (rs.next()) {
				Ajuda tr = new Ajuda();
				tr.setId( rs.getString("cd_ajuda") );
				tr.setDescricao( rs.getString("mm_ajuda") );
				tr.setTitulo( rs.getString("no_titulo") );
				retorno.add(tr);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	
	public void buscar(String cd) {
		String SQL = "SELECT * FROM ajuda WHERE cd_ajuda='"+cd+"'";

		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(rs.getString("cd_ajuda"));
				setIdOriginal(rs.getString("cd_ajuda"));
				setDescricao( rs.getString("mm_ajuda") );
				setTitulo( rs.getString("no_titulo") );
			}
		}
		catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	public static ArrayList listarTodos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_tipo FROM tipo_requisito ORDER BY no_tipo";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				A.add(new Integer(rs.getInt("cd_tipo")));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	/*
	
	public static String getHtmlCombo(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		String SQL = "SELECT cd_tipo, no_tipo FROM tipo_requisito ORDER BY no_tipo";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {                                
				html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return html.toString();
		
	}      
	*/
	
	
	/**
	 * @return Returns the descricao.
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao The descricao to set.
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}




	public String getId() {
		return id;
	}




	public void setId(String id) {
		this.id = id;
	}




	public String getIdOriginal() {
		return idOriginal;
	}




	public void setIdOriginal(String idOriginal) {
		this.idOriginal = idOriginal;
	}




	public String getTitulo() {
		return titulo;
	}




	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	
}