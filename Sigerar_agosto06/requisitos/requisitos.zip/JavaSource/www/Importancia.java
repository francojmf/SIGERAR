package www;

import java.sql.*;
import java.util.*;

public class Importancia {
	private int id;
	private String descricao="";
	private int peso;
	
	public Importancia() {
	}
	
	public static String getHtmlCombo(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		String SQL = "SELECT cd_importancia, mm_descricao FROM importancia ORDER BY mm_descricao";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {                                
				html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return html.toString();
		
	}      
	
	public void cadastrar() {
		
		Database database = new Database();
		
		try {
			String SQL;
			
			int newId=0;
			SQL = "select max(cd_importancia) from importancia";
			ResultSet rs = database.stmt.executeQuery( SQL );
			if (rs.next()) {                              
				System.out.println( "ultimoid " + rs.getInt(1));
				newId = rs.getInt(1);
			}
			
			newId++;                        
			SQL = 
				"INSERT INTO importancia (cd_importancia, mm_descricao, vl_peso) VALUES (" + newId + ",'"+          
				descricao + "','"+peso  + "')";
			
			System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	public void alterar() {
		String SQL =
			"UPDATE importancia set "+
			"mm_descricao='" + getDescricao() + "',vl_peso='"+ getPeso() + "' where " +
			"cd_importancia=" + getId();
		System.out.println(SQL);
		Database database = new Database();
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	
	public void excluir() throws Exception {
		
		String SQL = "DELETE FROM importancia where cd_importancia="+ getId();
		
		Database database = new Database();
		
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Erro ao apagar importancia.");
			
		}
		database.fechar();
		
	}
	
	
	public static ArrayList buscaImportancia(String trecho_nome, Pager pager) {

		String SQL =
			" FROM importancia WHERE mm_descricao LIKE '%"+
			trecho_nome + "%' ";
		
		
		ArrayList retorno = new ArrayList();
		Database database = new Database();
		try {
		   int count = 0;
		   ResultSet rs = database.stmt.executeQuery("SELECT count(cd_importancia) "+SQL);
		   while (rs.next()) {
		    count = rs.getInt(1);
		   }
		   
		   pager.setTotal(count);

		   rs = database.stmt.executeQuery( pager.formatSql("SELECT cd_importancia "+SQL+" ORDER BY mm_descricao") );
			while (rs.next()) {
				Importancia i = new Importancia();
				i.buscar(rs.getInt("cd_importancia"));
				retorno.add(i);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	
	public void buscar(int cd) {
		String SQL =
			"SELECT * FROM importancia WHERE cd_importancia="+cd;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(cd);
				setDescricao(rs.getString("mm_descricao"));
				setPeso(rs.getInt("vl_peso"));
			}
			// System.out.println("fim");   
			
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	public static ArrayList listarTodos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_importancia FROM importancia ORDER BY mm_descricao";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				A.add(new Integer(rs.getInt("cd_importancia")));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	/*     public static String getHtmlCombo(int selected) {
	 
	 StringBuffer html = new StringBuffer();
	 
	 String SQL = "SELECT cd_usuario, no_usuario FROM usuario ORDER BY no_usuario";
	 
	 database.abrir_banco();
	 try {
	 
	 ResultSet rs = database.stmt.executeQuery(SQL);
	 while (rs.next()) {                                
	 html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
	 }
	 
	 } catch (java.lang.Exception erro) {
	 erro.printStackTrace();
	 }
	 database.fechar_banco();
	 return html.toString();
	 
	 }      */

	

	
	public static Importancia getImportanciaPadrao() {
		String SQL = "select first 1 cd_importancia FROM importancia";

		Importancia m = null;
		
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				m = new Importancia();
				m.buscar(rs.getInt("cd_importancia"));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		
		return m;
	}
	
		
	
	
	/**
	 * @return Returns the descricao.
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao The descricao to set.
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the peso.
	 */
	public int getPeso() {
		return peso;
	}
	/**
	 * @param peso The peso to set.
	 */
	public void setPeso(int peso) {
		this.peso = peso;
	}
}