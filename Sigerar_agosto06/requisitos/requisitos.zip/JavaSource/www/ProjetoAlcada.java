package www;

/**
 * <p>Title: ProjetoAlcada</p>
 * <p>Description: Projeto com Al�ada - para o usu�rio</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */


public class ProjetoAlcada {
        
        Alcada alc;
        Projeto proj;

        
        public ProjetoAlcada(int cd_projeto, int cd_alcada) {
                alc = new Alcada();
                alc.buscar( cd_alcada );
                
                proj = new Projeto();
                proj.buscar( cd_projeto );
        }
        
        
        public ProjetoAlcada(int cd_projeto, Alcada alc) {
                this.alc = alc;
                
                proj = new Projeto();
                proj.buscar( cd_projeto );
        }
        
        
        public Projeto getProjeto() {
                return proj;
        }
                
        public Alcada getAlcada() {
                return alc;
        }
                
        
}