package www;

import java.sql.ResultSet;
import java.util.ArrayList;

public class TipoDocumento {
	
	private String id="";
	private String nome = "";
	
	
	public void cadastrar() throws Exception {
		Database database = new Database();
		try {
			
			String SQL;
			
			int newId=0;
			SQL = "select max(cd_tipo_documento) from tipo_documento";
			ResultSet rs = database.stmt.executeQuery( SQL );
			if (rs.next()) {
				newId = rs.getInt(1);
			}                        
			newId++;
			

			SQL =   "INSERT INTO tipo_documento (cd_tipo_documento, no_tipo) VALUES (" + newId + ",'"+
			getNome()+"')";
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			
			erro.printStackTrace();
			
			throw new Exception("Problemas ao cadastrar!");
		}
		database.fechar();
	}
	
	
	
	
	public void alterar() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL = "update tipo_documento set no_tipo='"+getNome() +
					"' where cd_tipo_documento=" + getId() +"";
			
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar tipo de requisito!");
		}
		database.fechar();
	}
	
	public void excluir() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL = "delete from tipo_documento where cd_tipo_documento=" + getId() + "";
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar tipo dos requisitos!");
		}
		database.fechar();
	}
	
	
	public static ArrayList buscaTipos(String trecho_nome, Pager pager) {
		
		String SQL =
			" FROM tipo_documento WHERE no_tipo LIKE '%"+
			trecho_nome + "%'";
		ArrayList retorno = new ArrayList();
		
		
		
		
		Database database = new Database();
		try {
			   int count = 0;
			   ResultSet rs = database.stmt.executeQuery("SELECT count(*) "+SQL);
			   while (rs.next()) {
			    count = rs.getInt(1);
			   }
			   
			   pager.setTotal(count);

			   rs = database.stmt.executeQuery( pager.formatSql("SELECT * "+SQL+" ORDER BY no_tipo") );
			while (rs.next()) {
				TipoDocumento tr = new TipoDocumento();
				tr.setId( rs.getString("cd_tipo_documento") );
				tr.setNome( rs.getString("no_tipo") );
				retorno.add(tr);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	
	public void buscar(int cd) {
		String SQL = "SELECT * FROM tipo_documento WHERE cd_tipo_documento="+cd+"";

		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(rs.getString("cd_tipo_documento"));
				setNome(rs.getString("no_tipo"));
			}
		}
		catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	/*
	public static ArrayList listarTodos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_tipo FROM tipo_requisito ORDER BY no_tipo";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				A.add(new Integer(rs.getInt("cd_tipo")));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	*/
	
	
	public static String getHtmlCombo(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		String SQL = "SELECT cd_tipo_documento, no_tipo FROM tipo_documento ORDER BY no_tipo";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {                                
				html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return html.toString();
		
	}      
	
	
	



	public String getId() {
		return id;
	}




	public void setId(String id) {
		this.id = id;
	}




	public String getNome() {
		return nome;
	}




	public void setNome(String nome) {
		this.nome = nome;
	}




	
}