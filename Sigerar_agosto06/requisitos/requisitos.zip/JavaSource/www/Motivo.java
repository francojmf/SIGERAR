package www;

import java.sql.ResultSet;
import java.util.ArrayList;

public class Motivo {
	
	private int id;

	private String descricao = "";

	private boolean padrao;

	private boolean padraoOriginal;

	private boolean inclusao;

	private boolean alteracao;

	public Motivo() {
	}

	public static String getHtmlCombo(int selected) {

		StringBuffer html = new StringBuffer();

		String SQL = "SELECT cd_motivo, mm_descricao FROM motivo where st_inclusao=0 and st_alteracao=0 ORDER BY mm_descricao";

		Database database = new Database();
		try {

			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				html.append("<option value='" + rs.getString(1) + "' "
						+ (selected == rs.getInt(1) ? "selected" : "") + ">"
						+ rs.getString(2) + "</option>");
			}

		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return html.toString();

	}

	public void cadastrar() {

		Database database = new Database();

		try {
			String SQL;

			int newId = 0;
			SQL = "select max(cd_motivo) from motivo";
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				System.out.println("ultimoid " + rs.getInt(1));
				newId = rs.getInt(1);
			}

			newId++;
			SQL = "INSERT INTO motivo (cd_motivo, mm_descricao, st_padrao, st_inclusao, st_alteracao) VALUES ("
					+ newId + ",'" + descricao + "', " + (padrao ? 1 : 0) + ",0,0)";
			database.stmt.execute(SQL);

			if (padrao) {
				SQL = "update motivo set st_padrao=0 where cd_motivo<>" + newId;
				System.out.println(SQL);
				database.stmt.execute(SQL);
			}

		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}

	public void alterar() {
		Database database = new Database();
		try {

			String SQL = "UPDATE motivo set " + "mm_descricao='"
					+ getDescricao() + "', st_padrao=" + (padrao ? 1 : 0)
					+ " where " + "cd_motivo=" + getId();
			database.stmt.execute(SQL);

			if (padrao != padraoOriginal && padrao) {
				SQL = "update motivo set st_padrao=0 where cd_motivo<>"
						+ getId();
				System.out.println(SQL);
				database.stmt.execute(SQL);
			}

		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}

	public void excluir() throws Exception {

		String SQL = "DELETE FROM motivo where cd_motivo=" + getId();

		Database database = new Database();

		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Erro ao apagar motivo.");

		}
		database.fechar();

	}

	public static ArrayList buscaMotivos(String trecho_nome, Pager pager) {
		String SQL = " FROM motivo WHERE mm_descricao LIKE '%" + trecho_nome
				+ "%' ";

		ArrayList retorno = new ArrayList();
		Database database = new Database();
		try {
			int count = 0;
			ResultSet rs = database.stmt
					.executeQuery("SELECT count(cd_motivo) " + SQL);
			while (rs.next()) {
				count = rs.getInt(1);
			}

			pager.setTotal(count);

			rs = database.stmt.executeQuery(pager.formatSql("SELECT cd_motivo "
					+ SQL + " ORDER BY mm_descricao"));
			while (rs.next()) {
				Motivo m = new Motivo();
				m.buscar(rs.getInt("cd_motivo"));
				retorno.add(m);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}

	public static Motivo getMotivoPadrao() {
		String SQL = "select cd_motivo FROM motivo WHERE st_padrao=1";

		Motivo m = null;
		
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				m = new Motivo();
				m.buscar(rs.getInt("cd_motivo"));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		
		return m;
	}

	public static Motivo getMotivoInclusao() {
		String SQL = "select cd_motivo FROM motivo WHERE st_inclusao=1";

		Motivo m = null;
		
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				m = new Motivo();
				m.buscar(rs.getInt("cd_motivo"));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		
		return m;
	}

	public static Motivo getMotivoAlteracao() {
		String SQL = "select cd_motivo FROM motivo WHERE st_alteracao=1";

		Motivo m = null;
		
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				m = new Motivo();
				m.buscar(rs.getInt("cd_motivo"));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		
		return m;
	}

	public void buscar(int cd) {
		String tempCD;
		tempCD = java.lang.Integer.toString(cd);
		String SQL = "SELECT * FROM motivo WHERE cd_motivo=" + tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(cd);
				setDescricao(rs.getString("mm_descricao"));
				setPadrao(rs.getInt("st_padrao") == 1);
				setPadraoOriginal(rs.getInt("st_padrao") == 1);
				setInclusao(rs.getInt("st_inclusao") == 1);
				setAlteracao(rs.getInt("st_alteracao") == 1);
			}
			// System.out.println("fim");

		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}

	/*
	 * public void buscarcd(int cd) { String tempCD; tempCD =
	 * java.lang.Integer.toString(cd); String SQL = "SELECT count(*) FROM
	 * motivo"; Database database = new Database(); try { ResultSet rs =
	 * database.stmt.executeQuery(SQL); if (rs.next()) { cd_motivo = cd; } //
	 * System.out.println("fim");
	 * 
	 *  } catch (java.lang.Exception erro) { erro.printStackTrace(); }
	 * database.fechar(); }
	 */
	/*
	 * public String trazCodigo(String cd) { String cmp = ""; Statement stm; try {
	 * stm = con.createStatement(); ResultSet rs = stm.executeQuery("Select " +
	 * qry); if (rs.next()) { cmp = rs.getString(1); } } catch (SQLException e) {
	 * System.out.println("Problemas na Query: Select " + qry); } return cmp; }
	 */

	/**
	 * @return Returns the descricao.
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao
	 *            The descricao to set.
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}

	public boolean isPadrao() {
		return padrao;
	}

	public void setPadrao(boolean padrao) {
		this.padrao = padrao;
	}

	public boolean isPadraoOriginal() {
		return padraoOriginal;
	}

	public void setPadraoOriginal(boolean padraoOriginal) {
		this.padraoOriginal = padraoOriginal;
	}

	public boolean isInclusao() {
		return inclusao;
	}

	private void setInclusao(boolean inclusao) {
		this.inclusao = inclusao;
	}

	public boolean isAlteracao() {
		return alteracao;
	}

	public void setAlteracao(boolean alteracao) {
		this.alteracao = alteracao;
	}
}