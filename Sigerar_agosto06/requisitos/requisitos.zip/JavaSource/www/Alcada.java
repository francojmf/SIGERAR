package www;

import java.sql.*;
import java.util.*;

public class Alcada {
        private int id;
        private String nome = "";
        private int interno;
        
        
        public static final int INTERNO_ADMINISTRADOR = 1;
        public static final int INTERNO_GERENTE = 2;


        public Alcada() {
        }


        public static Alcada getAlcadaInterna(int i) {
                
                String SQL = "SELECT * FROM alcada WHERE st_interno="+i;
                
                Alcada retorno = null;
                
                Database database = new Database();
                try {
                        ResultSet rs = database.stmt.executeQuery(SQL);
                        if (rs.next()) {
                                retorno = new Alcada();
                                retorno.buscar( rs.getInt(1) );
                        }

                }
                catch (java.lang.Exception erro) {
                        erro.printStackTrace();
                }
                database.fechar();
                
                return retorno;
                
        }

        public void buscar(int cd) {
                String tempCD;
                tempCD = Integer.toString(cd);
                String SQL = "SELECT * FROM alcada WHERE cd_alcada="+tempCD;
                Database database = new Database();
                try {
                        ResultSet rs = database.stmt.executeQuery(SQL);
                        if (rs.next()) {
                                setId(cd);
                                setNome(rs.getString("no_alcada"));
                                setInterno(rs.getInt("st_interno"));
                        }

                }
                catch (java.lang.Exception erro) {
                        erro.printStackTrace();
                }
                database.fechar();
        }

        
        public static ArrayList listar() {
                ArrayList A = new ArrayList();
                String SQL = "SELECT cd_alcada FROM alcada where st_interno=0 ORDER BY no_alcada";
                Database database = new Database();
                try {
                        ResultSet rs = database.stmt.executeQuery(SQL);
                        while (rs.next()) {
                                Alcada alc = new Alcada();
                                alc.buscar( rs.getInt("cd_alcada") );
                                A.add( alc );
                        }
                } catch (java.lang.Exception erro) {
                        erro.printStackTrace();
                }
                database.fechar();
                return A;
        }
        
        
        public static ArrayList listarTodos() {
                ArrayList A = new ArrayList();
                String SQL = "SELECT cd_alcada FROM alcada ORDER BY no_alcada";
                Database database = new Database();
                try {
                        ResultSet rs = database.stmt.executeQuery(SQL);
                        while (rs.next()) {
                                Alcada alc = new Alcada();
                                alc.buscar( rs.getInt("cd_alcada") );
                                A.add( alc );
                        }
                } catch (java.lang.Exception erro) {
                        erro.printStackTrace();
                }
                database.fechar();
                return A;
        }
        
        
        
        public boolean temPermissao( String permissao ) {
                boolean retorno = false;
                
                String sql = "SELECT count(*) from alcada_permissao where cd_alcada=" + getId() + " and cd_permissao='" + permissao + "'";
                Database database = new Database();
                try {
                        ResultSet rs = database.stmt.executeQuery(sql);
                        while (rs.next()) {
                                retorno = rs.getInt(1)>0;
                        }
                } catch (java.lang.Exception erro) {
                        erro.printStackTrace();
                }
                database.fechar();
                
                return retorno;
        }
        
        
        
        
        
        
		/**
		 * @return Returns the id.
		 */
		public int getId() {
			return id;
		}
		/**
		 * @param id The id to set.
		 */
		public void setId(int id) {
			this.id = id;
		}
		/**
		 * @return Returns the interno.
		 */
		public int getInterno() {
			return interno;
		}
		/**
		 * @param interno The interno to set.
		 */
		public void setInterno(int interno) {
			this.interno = interno;
		}
		/**
		 * @return Returns the nome.
		 */
		public String getNome() {
			return nome;
		}
		/**
		 * @param nome The nome to set.
		 */
		public void setNome(String nome) {
			this.nome = nome;
		}
}