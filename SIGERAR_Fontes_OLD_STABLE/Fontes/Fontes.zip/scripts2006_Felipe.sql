-- usuario
CREATE TABLE usuario ( 
cd_usuario INTEGER NOT NULL, 
no_usuario VARCHAR (40) NOT NULL, 
cd_departamento INTEGER NOT NULL, 
no_cargo VARCHAR (40) NOT NULL, 
nr_fone VARCHAR (30) NOT NULL,
no_email VARCHAR (128) NOT NULL,
no_conhecimento VARCHAR (40) NOT NULL,
no_login VARCHAR(30) NOT NULL,
no_senha VARCHAR(10) NOT NULL,
CONSTRAINT pk_usuario PRIMARY KEY(cd_usuario)
);


--------------------------------------------------------------------------------

-- pq repete esta a��o?
ALTER TABLE usuario ADD no_login VARCHAR(30) NOT NULL;
ALTER TABLE usuario ADD no_senha VARCHAR(10) NOT NULL;

-- departamento
CREATE TABLE departamento ( 
cd_departamento INTEGER NOT NULL, 
no_departamento VARCHAR (40) NOT NULL, 
no_observacao VARCHAR (128) NOT NULL, 
CONSTRAINT pk_departamento PRIMARY KEY(cd_departamento)
);
#ALTER TABLE departamento alter column no_descricao to no_observacao


--------------------------------------------------------------------------------

-- projeto
CREATE TABLE projeto ( 
cd_projeto INTEGER NOT NULL, 
no_projeto VARCHAR (40) NOT NULL, 
ds_projeto VARCHAR(255) NOT NULL,
cd_gerente int NOT NULL,
CONSTRAINT pk_projeto PRIMARY KEY(cd_projeto)
);
ALTER TABLE projeto ADD dt_inicio date NOT NULL;
ALTER TABLE projeto DROP column dt_fim;
ALTER TABLE projeto ADD dt_cancelamento date;


--------------------------------------------------------------------------------

-- risco
CREATE TABLE risco ( 
cd_risco INTEGER NOT NULL, 
mm_descricao BLOB SUB_TYPE 1 NOT NULL,
vl_peso INTEGER NOT NULL,
CONSTRAINT pk_risco PRIMARY KEY(cd_risco)
);


--------------------------------------------------------------------------------

-- importancia
CREATE TABLE importancia ( 
cd_importancia INTEGER NOT NULL, 
mm_descricao BLOB SUB_TYPE 1 NOT NULL,
vl_peso INTEGER NOT NULL,
CONSTRAINT pk_importancia PRIMARY KEY(cd_importancia)
);


--------------------------------------------------------------------------------

-- impacto
CREATE TABLE impacto ( 
cd_impacto INTEGER NOT NULL, 
mm_descricao BLOB SUB_TYPE 1 NOT NULL,
vl_peso INTEGER NOT NULL,
CONSTRAINT pk_impacto PRIMARY KEY(cd_impacto)
);


--------------------------------------------------------------------------------

-- glossario
CREATE TABLE glossario ( 
cd_glossario INTEGER NOT NULL, 
no_glossario VARCHAR (40) NOT NULL, 
ds_glossario BLOB SUB_TYPE 1 NOT NULL,
dt_inicio date NOT NULL,
dt_cancelamento date,
CONSTRAINT pk_projeto PRIMARY KEY(cd_glossario)
);


--------------------------------------------------------------------------------

-- termo
CREATE TABLE termo ( 
cd_termo INTEGER NOT NULL, 
cd_glossario INTEGER NOT NULL, 
no_termo VARCHAR (40) NOT NULL, 
ds_termo BLOB SUB_TYPE 1 NOT NULL,
CONSTRAINT pk_termo PRIMARY KEY(cd_termo)
);


--------------------------------------------------------------------------------

-- projeto_glossario
CREATE TABLE projeto_glossario ( 
cd_projeto INTEGER NOT NULL, 
cd_glossario INTEGER NOT NULL, 
CONSTRAINT pk_projeto_glossario PRIMARY KEY(cd_projeto,cd_glossario)
);


--------------------------------------------------------------------------------

-- versaoreq_controleversao
CREATE TABLE versaoreq_controleversao ( 
cd_versao INTEGER NOT NULL, 
cd_controleversao INTEGER NOT NULL, 
CONSTRAINT pk_versaoreq_controleversao PRIMARY KEY(cd_vers�o,cd_controleversao)
);


--------------------------------------------------------------------------------

-- projeto_usuario
CREATE TABLE projeto_usuario ( 
cd_projeto INTEGER NOT NULL, 
cd_usuario INTEGER NOT NULL, 
cd_alcada INTEGER NOT NULL, 
dt_inicio date NOT NULL,
dt_cancelamento date,
CONSTRAINT pk_projeto_usuario PRIMARY KEY(cd_projeto,cd_usuario,dt_inicio)
);


--------------------------------------------------------------------------------

-- controleversao
CREATE TABLE controleversao ( 
cd_controleversao INTEGER NOT NULL, 
mm_descricao BLOB SUB_TYPE 1 NOT NULL,
tipo_documento VARCHAR (40) NOT NULL,
CONSTRAINT pk_controleversao PRIMARY KEY(cd_controleversao)
);

DROP table requisito;


--------------------------------------------------------------------------------

-- requisito
CREATE TABLE requisito (
cd_requisito INTEGER NOT NULL PRIMARY KEY,
nr_ordem INTEGER NOT NULL,
cd_completo VARCHAR(100) NOT NULL,
cd_requisito_pai INTEGER references requisito(cd_requisito),
cd_tipo INTEGER NOT NULL references tipo_requisito(cd_tipo),
no_requisito VARCHAR(40) NOT NULL,
cd_volatilidade INTEGER NOT NULL references volatilidade(cd_volatilidade),
cd_usuario INTEGER NOT NULL references usuario(cd_usuario),
cd_projeto INTEGER NOT NULL references projeto(cd_projeto)
)

ALTER TABLE requisito ADD dt_cancelamento datetime;


--------------------------------------------------------------------------------

-- sequencia para requisito

CREATE GENERATOR gen_cd_requisito;



--------------------------------------------------------------------------------

-- auto_requisito

set term @;


create trigger auto_requisito for requisito
active before insert position 0 as 
declare variable v_completo VARCHAR(100);
declare variable v_ordem int;
BEGIN

	if (new.cd_requisito_pai is null) then BEGIN
		select max(nr_ordem) from requisito where cd_requisito_pai is null and cd_projeto=new.cd_projeto into :v_ordem;
		v_completo = '';
	END
	if (not new.cd_requisito_pai is null) then BEGIN
		select cd_completo, 
		(select max(nr_ordem) from requisito where cd_requisito_pai=r.cd_requisito) 
		from requisito r where cd_requisito = new.cd_requisito_pai and cd_projeto=new.cd_projeto into :v_completo, :v_ordem;
	END

	if (v_ordem is null) then BEGIN
		v_ordem=0;
	END

	v_ordem = v_ordem + 1;
	
	new.nr_ordem = v_ordem;
	
	if (v_completo='') then 
		new.cd_completo = v_ordem;
	if (v_completo<>'') then 
		new.cd_completo = v_completo||'.'||v_ordem;

	new.cd_requisito = gen_id(gen_cd_requisito, 1);
END


@ 


DROP trigger auto_requisito@

set term ;@












--------------------------------------------------------------------------------

-- auto_versao_requisito
create trigger auto_versao_requisito for versao_requisito
active before insert position 0 as 
declare variable v_versao int;
BEGIN

	if (new.cd_requisito is null) then
		EXCEPTION SEM_REQUISITO;
	
	select max(cd_versao) from versao_requisito where cd_requisito=new.cd_requisito into :v_versao;

	if (v_versao is null) then 
		v_versao=0; 
	
	v_versao = v_versao + 1;
	
	new.cd_versao = v_versao;
END
@ 


--------------------------------------------------------------------------------

-- versa_requisito
CREATE TABLE versao_requisito ( 
cd_versao INTEGER NOT NULL, 
cd_requisito INTEGER NOT NULL, 
no_versao VARCHAR (40) NOT NULL,
dt_solicitacao date NOT NULL,
cd_usuario_solicitante INTEGER NOT NULL, 
cd_usuario_responsavel INTEGER NOT NULL, 
mm_descricao BLOB SUB_TYPE 1 NOT NULL,
prioridade VARCHAR (40) NOT NULL, 
custo VARCHAR (40) NOT NULL,
cd_motivo INTEGER NOT NULL, 
cd_risco INTEGER NOT NULL, 
cd_importancia INTEGER NOT NULL, 
cd_impacto INTEGER NOT NULL, 
cd_situacao INTEGER NOT NULL, 
CONSTRAINT pk_versaoreq PRIMARY KEY(cd_versao,cd_requisito)
);



--------------------------------------------------------------------------------

-- VERIFICAR - NAO SEI
ALTER TABLE projeto_usuario ADD dt_inicio date NOT NULL, ADD dt_cancelamento date;


--------------------------------------------------------------------------------

-- alcada
CREATE TABLE alcada (
        cd_alcada INTEGER NOT NULL,
        no_alcada VARCHAR (40) NOT NULL,
        st_interno smallint NOT NULL,
        CONSTRAINT pk_alcada PRIMARY KEY(cd_alcada)
);
insert into alcada (cd_alcada, no_alcada, st_interno) values (1, 'Gerente', 1);
insert into alcada (cd_alcada, no_alcada, st_interno) values (2, 'Administrador', 1);
insert into alcada (cd_alcada, no_alcada, st_interno) values (3, 'Analista Respons�vel', 0);
insert into alcada (cd_alcada, no_alcada, st_interno) values (4, 'Analista', 0);
insert into alcada (cd_alcada, no_alcada, st_interno) values (5, 'Usu�rio Respons�vel', 0);
insert into alcada (cd_alcada, no_alcada, st_interno) values (6, 'Usu�rio', 0);


--------------------------------------------------------------------------------

CREATE TABLE alcada_permissao ( 
cd_alcada INTEGER NOT NULL, 
cd_permissao VARCHAR(20) NOT NULL, 
CONSTRAINT pk_alcada_permissao PRIMARY KEY(cd_alcada,cd_permissao)
);


ALTER TABLE DATI ADD CONSTRAINT DATI FOREIGN KEY (DATI) REFERENCES ANAG(DATI) ON UPDATE CASCADE;
ALTER TABLE DATI ADD CONSTRAINT ID_ FOREIGN KEY (ID) REFERENCES ANAG(ID) ON DELETE CASCADE; 

ALTER TABLE departamento alter column no_descricao to no_observacao

ALTER TABLE versaoreq alter column no_versao to cd_controleversao

select g.cd_glossario, g.no_glossario
from projeto_glossario pg, glossario g
where pg.cd_glossario = g.cd_glossario
and pg.cd_projeto=9


--------------------------------------------------------------------------------

-- requisito dependente
CREATE TABLE requisito_dependente ( 
cd_requisito INTEGER NOT NULL, 
cd_requisito_superior INTEGER NOT NULL, 
PRIMARY KEY (cd_requisito,cd_requisito_superior)
);


--------------------------------------------------------------------------------

-- projeto glossario
CREATE TABLE projeto_glossario ( 
cd_projeto INTEGER NOT NULL, 
cd_glossario INTEGER NOT NULL, 
CONSTRAINT pk_projeto_glossario PRIMARY KEY(cd_projeto,cd_glossario)
);


--------------------------------------------------------------------------------

-- projeto_usuario
ALTER TABLE projeto_usuario
ADD CONSTRAINT fk_cd_usuario foreign key (cd_usuario) references usuario(cd_usuario)
ADD CONSTRAINT fk_cd_projeto foreign key (cd_projeto) references projeto(cd_projeto)


--------------------------------------------------------------------------------

-- motivo
ALTER TABLE motivo
ADD st_padrao smallint default 0;


--------------------------------------------------------------------------------

-- alteracao_versao
CREATE TABLE alteracao_versao (
	cd_alteracao int NOT NULL PRIMARY KEY,
	cd_requisito int NOT NULL references requisito (cd_requisito),
	cd_versao int NOT NULL,
	cd_versao_anterior int NOT NULL,
	vl_custo_total decimal(10,3)
)


--------------------------------------------------------------------------------

-- alteracao_versao_dependente
CREATE TABLE alteracao_versao_dependente (
	cd_alteracao int NOT NULL references alteracao_versao (cd_alteracao),
	cd_requisito int NOT NULL references requisito (cd_requisito),
	cd_versao int NOT NULL,
	cd_versao_anterior int NOT NULL
)


--------------------------------------------------------------------------------

-- generator
CREATE GENERATOR gen_cd_alteracao;
SET GENERATOR gen_cd_alteracao to 0;


--------------------------------------------------------------------------------

-- tirger auto_alteracao_versao
create trigger auto_alteracao_versao for alteracao_versao
active before insert position 0 as 
BEGIN
	new.cd_alteracao = gen_id(gen_cd_alteracao, 1);
END
@ 


--------------------------------------------------------------------------------

-- alteracao_versao_dependente
ALTER TABLE alteracao_versao_dependente
DROP CD_VERSAO, DROP CD_VERSAO_ANTERIOR

ALTER TABLE alteracao_versao_dependente ADD
CD_VERSAO INTEGER,
ADD CD_VERSAO_ANTERIOR INTEGER


--------------------------------------------------------------------------------

-- alteracao_versao
ALTER TABLE alteracao_versao ADD
CD_VERSAO INTEGER,
ADD CD_VERSAO_ANTERIOR INTEGER,
ADD VL_CUSTO_TOTAL DECIMAL(10, 3)


--------------------------------------------------------------------------------

-- mensagem
CREATE TABLE mensagem (
	cd_mensagem int NOT NULL PRIMARY KEY,
	dh_envio timestamp,
	cd_usuario_remetente int NOT NULL references usuario(cd_usuario),
	no_assunto VARCHAR(200) NOT NULL,
	mm_mensagem BLOB SUB_TYPE 1 NOT NULL,
	cd_usuario_destinatario int references usuario(cd_usuario),
	dh_leitura timestamp,
	st_apagado_remetente smallint default 0,
	st_apagado_destinatario smallint default 0
)


--------------------------------------------------------------------------------

-- mensagem_requisito
CREATE TABLE mensagem_requisito (
	cd_mensagem int NOT NULL PRIMARY KEY references mensagem(cd_mensagem),
	cd_requisito int references requisito(cd_requisito),
	cd_usuario_destinatario int references usuario(cd_usuario),
	st_lido int NOT NULL
)

-- generator
CREATE GENERATOR gen_cd_mensagem;
SET GENERATOR gen_cd_mensagem to 0;


-- auto_messagem

create trigger auto_mensagem for mensagem
active before insert position 0 as 
BEGIN
	new.cd_mensagem = gen_id(gen_cd_mensagem, 1);
END
@ 

-- drop messagem
DROP table mensagem;

-- tbl messagem
CREATE TABLE mensagem (
	cd_mensagem int NOT NULL PRIMARY KEY,
	dh_envio timestamp,
	cd_usuario_remetente int references usuario(cd_usuario),
	cd_requisito_remetente int references requisito(cd_requisito),
	cd_usuario_destinatario int references usuario(cd_usuario),
	cd_requisito_destinatario int references requisito(cd_requisito),
	no_assunto VARCHAR(200) NOT NULL,
	mm_mensagem BLOB SUB_TYPE 1 NOT NULL,
	dh_leitura timestamp,
	st_apagado_remetente smallint default 0,
	st_apagado_destinatario smallint default 0
)

-- repitido?
CREATE GENERATOR gen_cd_mensagem;
SET GENERATOR gen_cd_mensagem to 0;

-- repitido?
create trigger auto_mensagem for mensagem
active before insert position 0 as 
BEGIN

	if (new.cd_usuario_destinatario is null and new.cd_requisito_destinatario is null) then
		exception EXC_MENSAGEM_FALTA_REMETENTE;
		
	if (new.cd_usuario_destinatario is null and new.cd_requisito_destinatario is null) then
		exception EXC_MENSAGEM_FALTA_REMETENTE;
		

	new.cd_mensagem = gen_id(gen_cd_mensagem, 1);
	
END
@ 

-- exce��es
DROP exception EXC_MENSAGEM_FALTA_REMETENTE;
DROP exception EXC_MENSAGEM_FALTA_DESTINATARIO;

create exception EXC_MENSAGEM_FALTA_REMETENTE 'E necessario um remetente para a mensagem';
create exception EXC_MENSAGEM_FALTA_DESTINATARIO 'E necessario um destinatario para a mensagem';


--------------------------------------------------------------------------------

-- mensagem_forum
CREATE TABLE mensagem_forum (
	cd_mensagem int NOT NULL PRIMARY KEY,
	cd_alteracao int references alteracao_versao(cd_alteracao),
	dh_envio timestamp,
	cd_usuario int references usuario(cd_usuario),
	no_assunto VARCHAR(200) NOT NULL,
	mm_mensagem BLOB SUB_TYPE 1 NOT NULL
);

-- generator
CREATE GENERATOR gen_cd_mensagem_forum;
SET GENERATOR gen_cd_mensagem_forum to 0;

-- triger
create trigger auto_mensagem_forum for mensagem_forum
active before insert position 0 as 
BEGIN

	new.cd_mensagem = gen_id(gen_cd_mensagem_forum, 1);
	
END
@ 


--------------------------------------------------------------------------------

-- ajuda
CREATE TABLE ajuda (

	cd_ajuda VARCHAR(30) NOT NULL PRIMARY KEY,
	mm_ajuda BLOB SUB_TYPE 1 NOT NULL

)


--------------------------------------------------------------------------------

-- usuario?
ALTER TABLE usuario ADD CONSTRAINT fk_cd_departamento  foreign key(cd_departamento) references departamento(cd_departamento);


--------------------------------------------------------------------------------

--  versao requisito
ALTER TABLE versao_requisito ADD CONSTRAINT fk_cd_usuario_solicitante  foreign key(cd_usuario_solicitante) references usuario(cd_usuario);

-- versao requisito
ALTER TABLE versao_requisito ADD CONSTRAINT fk_cd_usuario_responsavel  foreign key(cd_usuario_responsavel) references usuario(cd_usuario);

-- versao requisito
ALTER TABLE versao_requisito ADD CONSTRAINT fk_cd_requisito  foreign key(cd_requisito) references requisito(cd_requisito);

-- versao requisito
ALTER TABLE versao_requisito ADD CONSTRAINT fk_cd_motico  foreign key(cd_motivo) references motivo(cd_motivo);

-- versao requisito
ALTER TABLE versao_requisito ADD CONSTRAINT fk_cd_risco  foreign key(cd_risco) references risco(cd_risco);

-- versao requisito
ALTER TABLE versao_requisito ADD CONSTRAINT fk_cd_importancia  foreign key(cd_importancia) references importancia(cd_importancia);

-- versao requisito
ALTER TABLE versao_requisito ADD CONSTRAINT fk_cd_impacto  foreign key(cd_impacto) references impacto(cd_impacto);

-- versao requisito
ALTER TABLE versao_requisito ADD CONSTRAINT fk_cd_situacao  foreign key(cd_situacao) references situacao(cd_situacao);


--------------------------------------------------------------------------------

-- usuario
ALTER TABLE usuario ADD ST_ADMIN smallint default 0;


--------------------------------------------------------------------------------

-- tipo_documento
DROP table tipo_documento;
CREATE TABLE tipo_documento (
	cd_tipo_documento int NOT NULL PRIMARY KEY,
	no_tipo VARCHAR(100)
)


--------------------------------------------------------------------------------

-- documento_versao
-- derrubar
DROP table documento_versao;

-- criar
CREATE TABLE documento_versao (
	cd_documento int NOT NULL PRIMARY KEY,
	cd_requisito int NOT NULL,
	cd_versao int NOT NULL,
	no_documento VARCHAR(200) NOT NULL,
	no_localizacao VARCHAR(200) NOT NULL,
	cd_tipo_documento int NOT NULL
)

ALTER TABLE documento_versao ADD CONSTRAINT fk_tipo  foreign key (cd_tipo_documento) references tipo_documento(cd_tipo_documento);

// n�o consegui:
ALTER TABLE documento_versao ADD CONSTRAINT fk_versao_requisito
	foreign key (cd_requisito, cd_versao) references versao_requisito(cd_requisito,cd_versao)


