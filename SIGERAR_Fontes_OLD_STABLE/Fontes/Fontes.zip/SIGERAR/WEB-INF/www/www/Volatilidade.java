package www;

import java.sql.*;
import java.util.*;

public class Volatilidade {
	private int id;
	private String descricao="";
	private int quantidadeMinima;
	private int quantidadeMaxima;
	private String mesesAConsiderar="";
	private int peso;
	
	public Volatilidade() {
	}
	
	public void cadastrar() {
		Database database = new Database();
		
		try {
			String SQL;
			
			int newId=0;
			SQL = "select max(cd_volatilidade) from volatilidade";
			ResultSet rs = database.stmt.executeQuery( SQL );
			if (rs.next()) {                              
				System.out.println( "ultimoid " + rs.getInt(1));
				newId = rs.getInt(1);
			}
			
			newId++;                        
			SQL = 
				"INSERT INTO volatilidade (cd_volatilidade, mm_descricao, qt_minima, qt_maxima, no_meses_considerar, vl_peso) VALUES (" + newId + ",'"+          
				getDescricao() + "',"+getQuantidadeMinima() + ","+getQuantidadeMaxima() + ","+getMesesAConsiderar() + ","+ getPeso()  + ")";
			
			System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}        
	
	
	public void alterar() {
		String SQL =
			"UPDATE volatilidade set "+
			"mm_descricao='" + descricao + "',qt_minima="+ getQuantidadeMinima() + ",qt_maxima='"+getQuantidadeMaxima() +
			"',no_meses_considerar='"+getMesesAConsiderar() +"',vl_peso='"+getPeso() + "' where " +
			"cd_volatilidade=" + getId();
		System.out.println(SQL);
		Database database = new Database();
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	
	public void excluir() throws Exception {
		
		String SQL = "DELETE FROM volatilidade where cd_volatilidade="+ getId();
		
		Database database = new Database();
		
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception  ("Erro ao apagar volatilidade.");
			
		}
		database.fechar();
		
	}
	
	
	public static ArrayList buscaVolatilidades(String trecho_nome, Pager pager) {
		
		String SQL =
			" FROM volatilidade WHERE mm_descricao LIKE '%"+
			trecho_nome + "%' ";
		
		ArrayList retorno = new ArrayList();
		Database database = new Database();
		try {
		   int count = 0;
		   ResultSet rs = database.stmt.executeQuery("SELECT count(cd_volatilidade) "+SQL);
		   while (rs.next()) {
		    count = rs.getInt(1);
		   }
		   
		   pager.setTotal(count);
		
		   rs = database.stmt.executeQuery( pager.formatSql("SELECT cd_volatilidade "+SQL+" ORDER BY mm_descricao") );
			while (rs.next()) {
				Volatilidade v = new Volatilidade();
				v.buscar( rs.getInt("cd_volatilidade") );
				retorno.add(v);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	
	public void buscar(int cd) {
		String tempCD;
		tempCD = java.lang.Integer.toString(cd);
		String SQL =
			"SELECT * FROM volatilidade WHERE cd_volatilidade="+tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(cd);
				setDescricao(rs.getString("mm_descricao"));
				setQuantidadeMinima(rs.getInt("qt_minima"));
				setQuantidadeMaxima(rs.getInt("qt_maxima"));
				setMesesAConsiderar(rs.getString("no_meses_considerar"));
				setPeso(rs.getInt("vl_peso"));
			}
			// System.out.println("fim");   
			
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	public static ArrayList listarTodos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_volatilidade FROM volatilidade ORDER BY mm_volatilidade";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				A.add(new Integer(rs.getInt("cd_volatilidade")));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	public static String getHtmlCombo(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		String SQL = "SELECT cd_volatilidade, mm_descricao FROM volatilidade ORDER BY mm_descricao";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {                                
				html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return html.toString();
		
	}      
	
	
	
	/**
	 * @return Returns the descricao.
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao The descricao to set.
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the mesesAConsiderar.
	 */
	public String getMesesAConsiderar() {
		return mesesAConsiderar;
	}
	/**
	 * @param mesesAConsiderar The mesesAConsiderar to set.
	 */
	public void setMesesAConsiderar(String mesesAConsiderar) {
		this.mesesAConsiderar = mesesAConsiderar;
	}
	/**
	 * @return Returns the peso.
	 */
	public int getPeso() {
		return peso;
	}
	/**
	 * @param peso The peso to set.
	 */
	public void setPeso(int peso) {
		this.peso = peso;
	}
	/**
	 * @return Returns the quantidadeMaxima.
	 */
	public int getQuantidadeMaxima() {
		return quantidadeMaxima;
	}
	/**
	 * @param quantidadeMaxima The quantidadeMaxima to set.
	 */
	public void setQuantidadeMaxima(int quantidadeMaxima) {
		this.quantidadeMaxima = quantidadeMaxima;
	}
	/**
	 * @return Returns the quantidadeMinima.
	 */
	public int getQuantidadeMinima() {
		return quantidadeMinima;
	}
	/**
	 * @param quantidadeMinima The quantidadeMinima to set.
	 */
	public void setQuantidadeMinima(int quantidadeMinima) {
		this.quantidadeMinima = quantidadeMinima;
	}
}