package www;

import java.io.IOException;
import java.io.Writer;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Usuario implements DestinatarioRemetente {
	private int id;
	private int idDepartamento;
	private String nome="";
	private String cargo="";
	private String fone="";
	private String email="";
	private String login="";
	private String senha="";
	private String conhecimento="nenhum";
	private boolean admin = false;
	
	public ProjetoAlcada projetoAtual=null;
	
	
	public Usuario() {
	}
	
	public static String getHtmlCombo(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		String SQL = "SELECT cd_usuario, no_usuario FROM usuario ORDER BY no_usuario";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {                                
				html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return html.toString();
		
	}      
	
	
	public String getDepartamento() {         
		Departamento dpto = new Departamento();
		dpto.buscar( getIdDepartamento() );                
		return dpto.getNome();
	} 
	
	
	public void cadastrar() {
		
		Database database = new Database();
		
		try {
			String SQL;
			
			int newId=0;
			SQL = "select max(cd_usuario) from usuario";
			ResultSet rs = database.stmt.executeQuery( SQL );
			if (rs.next()) {                              
				System.out.println( "ultimoid " + rs.getInt(1));
				newId = rs.getInt(1);
			}
			
			newId++;                        
			SQL = 
				"INSERT INTO usuario (cd_usuario, no_usuario, cd_departamento, no_cargo, no_fone, no_email, no_conhecimento, no_login, no_senha, st_admin) VALUES (" + newId + ",'"+
				getNome() + "',"+getIdDepartamento() + ",'"+getCargo() +
				"','"+getFone() + "','"+getEmail() + "','"+
				getConhecimento() + "','"+getLogin()+"','"+getSenha()+"', 0)";
			
//			System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	public void alterar() {
		String SQL =
			"UPDATE usuario set "+
			"no_usuario='" + getNome() + "',cd_departamento="+getIdDepartamento() + ",no_cargo='"+getCargo() +
			"',no_fone='"+getFone() + "',no_email='"+getEmail() + "',no_conhecimento='"+getConhecimento() + "',no_login='"+getLogin()+ "'" +
			(!getSenha().equals("")?",no_senha='"+getSenha()+ "'":"") +
			" where " +
			"cd_usuario=" + getId();
		System.out.println(SQL);
		Database database = new Database();
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	
	public void excluir() throws Exception {
		
		String SQL = "DELETE FROM usuario where st_admin=0 and cd_usuario="+ getId();
		// String SQL = "DELETE FROM usuario p where p.cd_usuario='"+ cd_usuario +"' not in (select cd_usuario='"+ cd_usuario +"' from projeto_usuario)";  
		// String SQL = "DELETE FROM usuario p where p.cd_usuario not in (select cd_usuario from projeto_usuario) where cd_usuario=" + cd_usuario;  
		
		
		
		System.out.println(SQL);
		
		Database database = new Database();
		
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Erro ao apagar usu?rio.");
			
		}
		database.fechar();
		
	}
	
	
	
	
	public static ArrayList buscar(String trecho_nome, Pager pager) {
		
		String SQL = " FROM usuario WHERE no_usuario LIKE '%"+
		trecho_nome + "%' ";
		
		ArrayList retorno = new ArrayList();
		Database database = new Database();
		try {
			
			int count = 0;
			ResultSet rs = database.stmt.executeQuery("SELECT count(cd_usuario) "+SQL);
			while (rs.next()) {
				count = rs.getInt(1);
			}
			
			pager.setTotal(count);
			
			// System.out.println(pager.formatSql("SELECT cd_usuario "+SQL+" ORDER BY no_usuario"));
			rs = database.stmt.executeQuery( pager.formatSql("SELECT cd_usuario "+SQL+" ORDER BY no_usuario") );
			while (rs.next()) {
				Usuario u = new Usuario();
				u.buscar(rs.getInt("cd_usuario"));
				retorno.add(u);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	
	public void buscar(int cd) {
		String tempCD;
		tempCD = java.lang.Integer.toString(cd);
		String SQL =
			"SELECT * FROM usuario WHERE cd_usuario="+tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(cd);
				setNome(rs.getString("no_usuario"));
				setIdDepartamento(rs.getInt("cd_departamento"));
				setCargo(rs.getString("no_cargo"));
				setFone(rs.getString("no_fone"));
				setEmail(rs.getString("no_email"));
				setConhecimento(rs.getString("no_conhecimento"));
				setLogin(rs.getString("no_login"));
				setAdmin( rs.getInt("st_admin")==1 );
				
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	public void total(int cd) {
		String tempCD;
		tempCD = java.lang.Integer.toString(cd);
		String SQL =
			"select max(cd_usuario) from usuario WHERE cd_usuario="+tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(cd);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	public static ArrayList listarTodos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_usuario FROM usuario ORDER BY no_usuario";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				Usuario u = new Usuario();
				u.buscar( rs.getInt("cd_usuario") );
				A.add( u );
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	
	
	/* fun??es de login */
	
	
	public static Usuario getUsuarioLogado( HttpSession session ) {
		Usuario retorno = null;
		
		if (session.getAttribute("usuario")!=null) {
			retorno = (Usuario)session.getAttribute("usuario");
		}
		
		return retorno;
	}
	
	
	public static Usuario doLogin ( HttpServletRequest request ) throws Exception {
		
		Usuario retorno = null;
		Cripto cpt = new Cripto();
		
		HttpSession session = request.getSession();
		
		String login = request.getParameter("login");
		if (login==null) login="";
		
		String senha = request.getParameter("senha");
		if (senha==null) {
			senha="";
		}
		else {
			senha = cpt.criptografar(senha);
		}
		
		
		String SQL = "SELECT cd_usuario FROM usuario where no_login='" + login + "' and no_senha='" + senha + "'";
		
		//System.out.println(SQL);
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {                                
				retorno = new Usuario();
				retorno.buscar( rs.getInt(1) );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
			throw new Exception( "Erro ao localizar usu?rio!" );
		}
		database.fechar();
		
		if (retorno==null) throw new Exception( "Usu?rio n?o encontrado!" );
		
		
		session.setAttribute("usuario", retorno);
		
		return retorno;
	}
	
	
	public ArrayList getProjetos() {
		
		ArrayList retorno = new ArrayList();
		
		String sql;
		
		Database database = new Database();
		try {
			
			// projetos onde o usu?rio ? Gerente
			sql = "select cd_projeto from projeto where dt_cancelamento is null and cd_gerente="+getId();
			
			ResultSet rs = database.stmt.executeQuery(sql);
			while (rs.next()) {                                
				retorno.add( new ProjetoAlcada( rs.getInt(1), Alcada.getAlcadaInterna(Alcada.INTERNO_GERENTE) ) );
			}
			
			// participa??es em todos os projetos
			sql = "select pu.cd_projeto, cd_alcada from projeto p, projeto_usuario pu " +
			"where pu.dt_cancelamento is null and p.dt_cancelamento is null and pu.cd_projeto = p.cd_projeto "+
			"and pu.cd_usuario=" + getId() + 
			" order by no_projeto";
			
			rs = database.stmt.executeQuery(sql);
			while (rs.next()) {                                
				retorno.add( new ProjetoAlcada( rs.getInt(1), rs.getInt(2) ) );
			}
			
			
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		
		
		return retorno;
	}
	
	
	
	
	public boolean temPermissao( String permissao ) {
		boolean retorno = false;
		
		if (projetoAtual!=null) {
			retorno = projetoAtual.getAlcada().temPermissao( permissao );
		}                
		return retorno;
	}
	
	
	
	public static boolean verificaLogin(HttpServletRequest request, HttpServletResponse response, Writer out, final String permissao) throws IOException {
		
		TestePermissao teste = new TestePermissao() {
				public boolean teste (Usuario u) {
					return u.temPermissao( permissao );
				}
			};
		
		return verificaLogin( request, response, out, teste );
		
	}
	
	
	public static boolean verificaLogin(HttpServletRequest request, HttpServletResponse response, Writer out) throws IOException {
		
		TestePermissao teste = new TestePermissao() {
				public boolean teste (Usuario u) {
					return true;
				}
			};
		
		return verificaLogin( request, response, out, teste );
		
	}
	
	
	public static boolean verificaLogin(HttpServletRequest request, HttpServletResponse response, Writer out, TestePermissao teste) throws IOException {
		
		Usuario logado = Usuario.getUsuarioLogado(request.getSession());

		if (logado==null) {
			
			out.write(
					"<SCRIPT language=\"JavaScript\">\n" +
					"autenticacaoDeslogado();\n"+
					"</SCRIPT>\n"
			);
			
			return false;

		} else if (logado.projetoAtual==null) {
			
			out.write(
					"<SCRIPT language=\"JavaScript\">\n" +
					"autenticacaoSemProjeto();\n"+
					"</SCRIPT>\n"
			);
			
			return false;

		} else if ( !teste.teste(logado) ) {
			
			out.write(
					"<SCRIPT language=\"JavaScript\">\n" +
					"autenticacaoSemPermissao();\n"+
					"</SCRIPT>\n"
			);
			
			return false;

		} else {
		        
			return true;

		}
		
	}
	public static boolean verificaLoginAdmin(HttpServletRequest request, HttpServletResponse response, Writer out) throws IOException {
		
		Usuario logado = Usuario.getUsuarioLogado(request.getSession());

		if (logado==null) {
			
			out.write(
					"<SCRIPT language=\"JavaScript\">\n" +
					"autenticacaoDeslogado();\n"+
					"</SCRIPT>\n"
			);
			
			return false;

		} else if (!logado.isAdmin()) {
			
			out.write(
					"<SCRIPT language=\"JavaScript\">\n" +
					"autenticacaoNaoAdmin();\n"+
					"</SCRIPT>\n"
			);
			
			return false;

		} else {
		        
			return true;

		}
		
	}
	
	
	/** para implementar DestinatarioRemetente **/
	public String getDescricao() {
		return getNome();
	}
	
	
	
	/**
	 * @return Returns the cargo.
	 */
	public String getCargo() {
		return cargo;
	}
	/**
	 * @param cargo The cargo to set.
	 */
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	/**
	 * @return Returns the conhecimento.
	 */
	public String getConhecimento() {
		return conhecimento;
	}
	/**
	 * @param conhecimento The conhecimento to set.
	 */
	public void setConhecimento(String conhecimento) {
		this.conhecimento = conhecimento;
	}
	/**
	 * @return Returns the email.
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email The email to set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return Returns the fone.
	 */
	public String getFone() {
		return fone;
	}
	/**
	 * @param fone The fone to set.
	 */
	public void setFone(String fone) {
		this.fone = fone;
	}
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the idDepartamento.
	 */
	public int getIdDepartamento() {
		return idDepartamento;
	}
	/**
	 * @param idDepartamento The idDepartamento to set.
	 */
	public void setIdDepartamento(int idDepartamento) {
		this.idDepartamento = idDepartamento;
	}
	/**
	 * @return Returns the login.
	 */
	public String getLogin() {
		return login;
	}
	/**
	 * @param login The login to set.
	 */
	public void setLogin(String login) {
		this.login = login;
	}
	/**
	 * @return Returns the projetoAtual.
	 */
	public ProjetoAlcada getProjetoAtual() {
		return projetoAtual;
	}
	/**
	 * @param projetoAtual The projetoAtual to set.
	 */
	public void setProjetoAtual(ProjetoAlcada projetoAtual) {
		this.projetoAtual = projetoAtual;
	}
	/**
	 * @return Returns the senha.
	 */
	public String getSenha() {
		return senha;
	}
	/**
	 * @param senha The senha to set.
	 */
	public void setSenha(String senha) {
		Cripto cpt = new Cripto();
		this.senha = cpt.criptografar(senha);
	}
	/**
	 * @return Returns the nome.
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome The nome to set.
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
	
	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public boolean equals (Object o) {
		
		if (o instanceof Usuario && ( (Usuario)o).getId() == getId() )
			return true;
		else return false;
		
	}
	
}
