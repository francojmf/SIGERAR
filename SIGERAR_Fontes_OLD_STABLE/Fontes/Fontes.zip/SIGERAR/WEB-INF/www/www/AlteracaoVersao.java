/*
 * Created on 30/08/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package www;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author marcelo
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AlteracaoVersao {
	
	private int id;
	
	private int idRequisito;
	private int idVersao;
	
	private int idVersaoAnterior;
	
	private int idAlteracaoPai;
	
	
	
	public static AlteracaoVersao getAlteracao (VersaoRequisito r) {
		AlteracaoVersao  reg = null;
		String SQL =
			"SELECT cd_alteracao FROM alteracao_versao " +
			"where cd_requisito="+r.getIdRequisito()+" and cd_versao="+r.getId()+" ";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				reg = new AlteracaoVersao();
				reg.preencher(rs);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return reg;
	}
	
	public void buscar(Requisito r, int cd) {
		String tempCD;
		tempCD = java.lang.Integer.toString(cd);
		String SQL =
			"SELECT * FROM versao_requisito WHERE cd_requisito=" + r.getId() + " and cd_versao="+tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				preencher(rs);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	void preencher(ResultSet rs) throws SQLException {
		setId(rs.getInt("cd_alteracao"));
		setIdRequisito(rs.getInt("cd_requisito"));
		setIdVersao(rs.getInt("cd_versao"));
		setIdVersaoAnterior(rs.getInt("cd_versao_anterior"));
		setIdAlteracaoPai( rs.getInt("cd_alteracao_pai") );
	}
	
	
	
	public static ArrayList listarTodos( Projeto p, boolean soAbertos ) {
		return listarTodos( p, null, soAbertos );
	}
	
	public static ArrayList listarTodos( Projeto p, Requisito r, boolean soAbertos ) {
		ArrayList A = new ArrayList();
		String SQL = "SELECT * FROM alteracao_versao a, requisito r " +
		"where a.cd_requisito = r.cd_requisito " +
		"and cd_alteracao_pai is null " +
		(  r==null?"":"and cd_requisito="+r.getId()+" " ) +
		" and r.cd_projeto=" + p.getId() + " " +
		" ORDER BY cd_alteracao desc";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			
			while (rs.next()) {
				AlteracaoVersao v = new AlteracaoVersao();
				v.preencher( rs );
				A.add(v);
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	
	
	public static ArrayList listarSubalteracoes( AlteracaoVersao av ) {
		ArrayList A = new ArrayList();
		String SQL= "SELECT av.* FROM alteracao_versao av, requisito r " +
		" where av.cd_requisito = r.cd_requisito" +
		" and cd_alteracao_pai=" + av.getId() + 
		" ORDER BY r.cd_completo ";
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			
			while (rs.next()) {
				AlteracaoVersao vd = new AlteracaoVersao();
				vd.preencher(rs);
				/*				vd.setId( rs.getInt("cd_alteracao") );
				 vd.setIdRequisito( rs.getInt("cd_requisito") );
				 vd.setIdVersao( rs.getInt("cd_versao") );
				 vd.setIdVersaoAnterior( rs.getInt("cd_versao_anterior") );
				 */
				A.add(vd);
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	
	
	
	
	
	public static AlteracaoVersao getAlteracao( int ida ) {
		AlteracaoVersao v = null;
		
		
		String SQL = "SELECT * FROM alteracao_versao " +
		"where cd_alteracao=" + ida + 
		" ORDER BY cd_alteracao desc";
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			
			while (rs.next()) {
				v = new AlteracaoVersao();
				v.preencher( rs );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		
		return v;
	}
	
	
	
	public static AlteracaoVersao criarNovaAlteracao( int idr, Usuario solicitante ) throws Exception {
		return criarNovaAlteracao( idr, solicitante, null, new ArrayList());
	}
	
	public static AlteracaoVersao criarNovaAlteracao( int idr, Usuario solicitante, AlteracaoVersao pai, ArrayList todos ) throws Exception {
		
		AlteracaoVersao reg = new AlteracaoVersao();
		
		Requisito r = new Requisito();
		r.buscar( idr );
		
		reg.setIdRequisito( r.getId() );
		
		todos.add( new Integer(r.getId()) );
		
		// s� cria a vers�o j� se for o primeiro...
		if (pai==null) {
			
			VersaoRequisito vr = VersaoRequisito.getUltimaVersao( r );
			
			if (vr==null || vr.getSituacao()==VersaoRequisito.SITUACAO_IMPLEMENTADO ) {
				
				VersaoRequisito novaVR = r.getNovaVersao( solicitante ); 
				
				novaVR.cadastrar();
				
				reg.setIdVersao( novaVR.getId() );
				reg.setIdVersaoAnterior( vr==null?0:vr.getId() );
				
				
			}
		}
		
		reg.setIdAlteracaoPai(  pai==null?0:pai.getId()  );
		reg.cadastrar();
		
		ArrayList requisitodDependentes = Requisito.listarRequisitosDependentes( r );
		
		for (int i=0; i<requisitodDependentes.size(); i++) {
			
			Requisito rdep = (Requisito) requisitodDependentes.get(i);
			
			if (!todos.contains( new Integer(rdep.getId()))) {
				
				criarNovaAlteracao( rdep.getId(), solicitante, reg, todos );
				
			}
			
		}
		
		
		/*		
		 
		 ArrayList requisitodDependentes = Requisito.listarRequisitosDependentes( r );
		 
		 for (int i=0; i<requisitodDependentes.size(); i++) {
		 
		 
		 AlteracaoVersao dep = new AlteracaoVersao();
		 //				dep.setId( reg.getId() );
		  dep.setIdRequisito( rdep.getId() );
		  
		  dep.cadastrar();
		  }
		  */
		
		return reg;
	}
	
	
	
	
	
	
	
	
	public VersaoRequisito criarNovaVersao( int idr, Usuario solicitante ) throws Exception {
		
		Requisito r = new Requisito();
		r.buscar( idr );
		
		VersaoRequisito vr = VersaoRequisito.getUltimaVersao( r );
		
		VersaoRequisito novaVR = r.getNovaVersao( solicitante ); 
		novaVR.setIdMotivo( Motivo.getMotivoAlteracao().getId() );
		novaVR.setSituacao( VersaoRequisito.SITUACAO_ANALISE );
		novaVR.cadastrar();
		
		this.setIdVersao( novaVR.getId() );
		this.setIdVersaoAnterior( vr==null?0:vr.getId() );
		
		
		this.alterar();
		
		return vr;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	public void cadastrar() {
		
		Database database = new Database();
		
		try {
			
			String SQL = "insert into ALTERACAO_VERSAO (CD_REQUISITO, " +
			"CD_VERSAO, CD_VERSAO_ANTERIOR, CD_ALTERACAO_PAI) values (" +
			getIdRequisito()+", " + getIdVersao() +", " + getIdVersaoAnterior() +", " +
			(getIdAlteracaoPai()==0?"null":""+getIdAlteracaoPai()) +
			")";
			
			database.stmt.execute(SQL);
			
			
			SQL = "select max(cd_alteracao) from alteracao_versao where cd_requisito=" + getIdRequisito();
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId( rs.getInt(1) );
			}
			
			
			
			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	
	
	
	public void alterar() {
		
		Database database = new Database();
		
		try {
			
			String SQL = "update ALTERACAO_VERSAO set " +
			"CD_VERSAO=" + getIdVersao() + ", CD_VERSAO_ANTERIOR=" + getIdVersaoAnterior() + ", " +
			"CD_ALTERACAO_PAI=" + (getIdAlteracaoPai()==0?"null":""+getIdAlteracaoPai()) + " " +
			" where cd_alteracao=" + getId();
			
			database.stmt.execute(SQL);
			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	public void excluir() {
		
		if (AlteracaoVersao.listarSubalteracoes( this ).size()==0) {
			
			Database database = new Database();
			
			try {
				
				String SQL = "delete from ALTERACAO_VERSAO where cd_alteracao=" + getId();
				database.stmt.execute(SQL);
				
			} catch (java.lang.Exception erro) {
				System.out.println(erro);
				erro.printStackTrace();
			}
			database.fechar();
		}
	}
	
	
	
	
	public void excluirTudo() {
		
		ArrayList filhos = AlteracaoVersao.listarSubalteracoes( this );
		
		for (int i=0; i<filhos.size(); i++) {
			AlteracaoVersao filho = (AlteracaoVersao)filhos.get(i);
			
			filho.excluirTudo();
			
		}

		
		Database database = new Database();
		
		try {
			
			String SQL = "delete from ALTERACAO_VERSAO where cd_alteracao=" + getId();
			
			database.stmt.execute(SQL);
			
			if (getIdVersao()!=0) {
				SQL = "delete from VERSAO_REQUISITO where cd_requisito=" + getIdRequisito() + " and cd_versao=" + getIdVersao();

				database.stmt.execute(SQL);
			}
				
			
			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			erro.printStackTrace();
		}
		database.fechar();


	}
	
	
	
	
	public AlteracaoVersao getPaiDeTodos() {
		
		if (getIdAlteracaoPai()==0) {
			return this;
		} else {
			return getAlteracao( getIdAlteracaoPai() ).getPaiDeTodos();
		}
	}
		
	public AlteracaoVersao getAlteracaoPai() {
		return getAlteracao( getIdAlteracaoPai() );
	}
	
	public VersaoRequisito getVersao() {
		if (getIdVersao() == 0) return null;
		else {
			Requisito r = new Requisito();
			r.buscar(getIdRequisito());
			
			return VersaoRequisito.getVersao(r,getIdVersao());
		}
	}
	
	
	public double getCustoTotal() {
		return getCustoTotal( null, null );
	}

	
	public double getCustoTotal( ArrayList ids, ArrayList custos ) {
		
		double custo = 0;
		
		if (getIdVersao()!=0) {
			VersaoRequisito vr = new VersaoRequisito();
			Requisito r = new Requisito();
			r.buscar( getIdRequisito() );
			vr.buscar( r, getIdVersao() );
			
			custo += vr.getCusto();
			
		}
		
		ArrayList subs = listarSubalteracoes( this );
		for (int i=0; i<subs.size(); i++) {
			AlteracaoVersao alt = (AlteracaoVersao)subs.get(i);
			
			custo += alt.getCustoTotal( ids, custos);
			
		}
		
		if (getIdVersao()!=0) {
			if (ids!=null) ids.add( new Integer(id) );
			if (custos!=null) custos.add( new Double(custo) );
		}
		
		return custo;
	}



	
	public boolean contem( Requisito r ) {
		
		if (getIdRequisito()==r.getId()) {
			return true;
		}
		ArrayList subs = listarSubalteracoes( this );
		for (int i=0; i<subs.size(); i++) {
			AlteracaoVersao alt = (AlteracaoVersao)subs.get(i);
			
			if (alt.contem( r )) return true;
			
		}
		return false;
	}



	
	public static void enviarMensagemResponsaveis(String mensagem, String assunto, AlteracaoVersao alteracao, Usuario remetente) {

		Requisito destinatario = new Requisito();
		destinatario.buscar( alteracao.getIdRequisito() );

//		if (!remetente.equals(destinatario)) {
			Mensagem m = new Mensagem();
			m.setRemetente( remetente );
			m.setDestinatario( destinatario );
			m.setMensagem(mensagem);
			m.setEnvio( new Date() );
			m.setAssunto(assunto);
			m.gravar();
//		}

		ArrayList subs = listarSubalteracoes( alteracao );
		for (int i=0; i<subs.size(); i++) {
			AlteracaoVersao alt = (AlteracaoVersao)subs.get(i);
			
			enviarMensagemResponsaveis(mensagem, assunto, alt, remetente); 
		}
		
	}
	

	
	
	
	
	public int getIdRequisito() {
		return idRequisito;
	}
	public void setIdRequisito(int idRequisito) {
		this.idRequisito = idRequisito;
	}
	public int getIdVersao() {
		return idVersao;
	}
	public void setIdVersao(int idVersao) {
		this.idVersao = idVersao;
	}
	public int getIdVersaoAnterior() {
		return idVersaoAnterior;
	}
	public void setIdVersaoAnterior(int idVersaoAnterior) {
		this.idVersaoAnterior = idVersaoAnterior;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public int getIdAlteracaoPai() {
		return idAlteracaoPai;
	}
	public void setIdAlteracaoPai(int idAlteracaoPai) {
		this.idAlteracaoPai = idAlteracaoPai;
	}
	
	
	
	public static void main( String[] args) {
		
		Database database = new Database();
		
		try {
			
			String SQL = "delete from mensagem_forum";
			database.stmt.execute(SQL);
			
			SQL = "delete from mensagem";
			database.stmt.execute(SQL);
			

			for (int i=0; i<44; i++) {
				
				SQL = "delete from alteracao_versao a where (select count(*) from alteracao_versao where cd_alteracao_pai=a.cd_alteracao) = 0";
				
				database.stmt.execute(SQL);
			}

			SQL = "delete from versao_requisito";
			database.stmt.execute(SQL);

			SQL = "delete from requisito_dependente";
			database.stmt.execute(SQL);

			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	
}
