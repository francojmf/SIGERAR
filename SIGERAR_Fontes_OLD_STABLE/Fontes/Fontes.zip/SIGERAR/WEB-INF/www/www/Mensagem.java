/*
 * Created on 21/09/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package www;

import www.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author marcelo
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Mensagem {

	int id;
	Date envio;
	String assunto;
	String mensagem;
	
	DestinatarioRemetente destinatario;
	DestinatarioRemetente remetente;
	
	Date leitura;
	
	
	
	public static ArrayList listarEnviados( Usuario remetente, Pager p ) {
		
		ArrayList lista= new ArrayList();
		
		
		Database database = new Database();
		try {
			
			String sql = "from mensagem where ST_APAGADO_REMETENTE=0 and " +
					"cd_usuario_remetente=" + remetente.getId();

			
			ResultSet rs = database.stmt.executeQuery("select count(*) " +  sql);
			
			while (rs.next()) {
				
				p.setTotal( rs.getInt(1) );
				
			}

			sql = "select CD_MENSAGEM, DH_ENVIO, " +
				"CD_USUARIO_REMETENTE, CD_USUARIO_DESTINATARIO, " +
				"CD_REQUISITO_REMETENTE, CD_REQUISITO_DESTINATARIO, " +
				"NO_ASSUNTO, MM_MENSAGEM, " +
				"DH_LEITURA " +
				sql +
				" order by dh_envio desc ";


			rs = database.stmt.executeQuery( p.formatSql(sql) );
			
			
			while (rs.next()) {

				Mensagem m = new Mensagem();
				
				m.preencher(rs);
		
				lista.add(m);
			}

		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return lista;
		
		
	}
	
	
	
	
	
	public static ArrayList listarCaixaEntrada( Usuario destinatario, Pager p ) {
		
		ArrayList lista=new ArrayList();
		
		
		Database database = new Database();
		try {
			
			String sql = 
				" from mensagem where ST_APAGADO_DESTINATARIO=0 and " +
				"cd_usuario_destinatario=" + destinatario.getId();
	
			ResultSet rs = database.stmt.executeQuery("select count(*) " + sql);
			
			while (rs.next()) {
				p.setTotal( rs.getInt(1) );
			}
			
			
			sql = "select CD_MENSAGEM, DH_ENVIO, " +
				"CD_USUARIO_REMETENTE, CD_USUARIO_DESTINATARIO, " +
				"CD_REQUISITO_REMETENTE, CD_REQUISITO_DESTINATARIO, " +
				"NO_ASSUNTO, MM_MENSAGEM, " +
				"DH_LEITURA " + 
				sql + 
				" order by dh_envio desc ";
	
//			System.out.println( p.formatSql( sql ) );
			
			rs = database.stmt.executeQuery( p.formatSql( sql ) );
			
			while (rs.next()) {
	
				Mensagem m = new Mensagem();
				
				m.preencher( rs );
				
				
				lista.add( m );
				
			}
	
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return lista;
		
		
	}
	
	
	
	public static ArrayList listarMensagensRequisito( Usuario responsavel, Projeto projeto, Pager p ) {
		
		ArrayList lista=new ArrayList();
		
		
		Database database = new Database();
		try {
			
			String sql = 
				" from mensagem m, requisito r " +
				" where ST_APAGADO_DESTINATARIO=0 and cd_requisito_destinatario=r.cd_requisito and " +
				"cd_projeto=" + projeto.getId() + " and cd_usuario= "+ responsavel.getId() + "";
	
			ResultSet rs = database.stmt.executeQuery("select count(*) " + sql);
			
			while (rs.next()) {
				p.setTotal( rs.getInt(1) );
			}
			
			
			sql = "select CD_MENSAGEM, DH_ENVIO, " +
				"CD_USUARIO_REMETENTE, CD_USUARIO_DESTINATARIO, " +
				"CD_REQUISITO_REMETENTE, CD_REQUISITO_DESTINATARIO, " +
				"NO_ASSUNTO, MM_MENSAGEM, " +
				"DH_LEITURA " + 
				sql + 
				" order by dh_envio desc ";
	
			//System.out.println( p.formatSql( sql ) );
			
			rs = database.stmt.executeQuery( p.formatSql( sql ) );
			
			while (rs.next()) {
	
				Mensagem m = new Mensagem();
				
				m.preencher( rs );
				
				
				lista.add( m );
				
			}
	
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return lista;
		
		
	}
	
	
	
	
	
	public static ArrayList listarMensagensRequisito( Requisito destinatario, Pager p ) {
		
		ArrayList lista=new ArrayList();
		
		
		Database database = new Database();
		try {
			
			String sql = 
				" from mensagem where ST_APAGADO_DESTINATARIO=0 and " +
				"cd_requisito_destinatario=" + destinatario.getId();
	
			ResultSet rs = database.stmt.executeQuery("select count(*) " + sql);
			
			while (rs.next()) {
				p.setTotal( rs.getInt(1) );
			}
			
			
			sql = "select CD_MENSAGEM, DH_ENVIO, " +
				"CD_USUARIO_REMETENTE, CD_USUARIO_DESTINATARIO, " +
				"CD_REQUISITO_REMETENTE, CD_REQUISITO_DESTINATARIO, " +
				"NO_ASSUNTO, MM_MENSAGEM, " +
				"DH_LEITURA " + 
				sql + 
				" order by dh_envio desc ";
	
			rs = database.stmt.executeQuery( p.formatSql( sql ) );
			
			while (rs.next()) {
	
				Mensagem m = new Mensagem();
				
				m.preencher( rs );
				
				
				lista.add( m );
				
			}
	
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return lista;
		
		
	}
	
	
	
	
	public static ArrayList listarMensagensEnviadasRequisito( Requisito destinatario, Pager p ) {
		
		ArrayList lista=new ArrayList();
		
		
		Database database = new Database();
		try {
			
			String sql = 
				" from mensagem where ST_APAGADO_DESTINATARIO=0 and " +
				"cd_requisito_remetente=" + destinatario.getId();
	
			ResultSet rs = database.stmt.executeQuery("select count(*) " + sql);
			
			while (rs.next()) {
				p.setTotal( rs.getInt(1) );
			}
			
			
			sql = "select CD_MENSAGEM, DH_ENVIO, " +
				"CD_USUARIO_REMETENTE, CD_USUARIO_DESTINATARIO, " +
				"CD_REQUISITO_REMETENTE, CD_REQUISITO_DESTINATARIO, " +
				"NO_ASSUNTO, MM_MENSAGEM, " +
				"DH_LEITURA " + 
				sql + 
				" order by dh_envio desc ";
	
			rs = database.stmt.executeQuery( p.formatSql( sql ) );
			
			while (rs.next()) {
	
				Mensagem m = new Mensagem();
				
				m.preencher( rs );
				
				
				lista.add( m );
				
			}
	
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return lista;
		
		
	}
	
	
	
	
	public static Mensagem getMensagemCaixaEntrada( int idm ) {
		
		Mensagem mensagem = null;
		
		
		Database database = new Database();
		try {
			
			String sql = "select CD_MENSAGEM, DH_ENVIO, " +
				"CD_USUARIO_REMETENTE, CD_USUARIO_DESTINATARIO, " +
				"CD_REQUISITO_REMETENTE, CD_REQUISITO_DESTINATARIO, " +
				"NO_ASSUNTO, MM_MENSAGEM, " +
				"DH_LEITURA " +
				" from " +
				"mensagem where cd_mensagem=?";
			
			PreparedStatement pstmt = database.conn.prepareStatement( sql );
			
			pstmt.setInt( 1, idm );
			
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
	
				mensagem = new Mensagem();

				mensagem.preencher( rs );
				
			}
	
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return mensagem;
		
		
	}

	
	void preencher( ResultSet rs ) throws SQLException {
		
		setId( rs.getInt("cd_mensagem") );
		setEnvio( rs.getTimestamp("dh_envio") );

		
		if (rs.getInt("cd_usuario_remetente")!=0) {
			Usuario remetente = new Usuario();
			remetente.buscar( rs.getInt("cd_usuario_remetente") );
	
			setRemetente( remetente );
		}
		
		if (rs.getInt("cd_requisito_remetente")!=0) {
			Requisito remetente = new Requisito();
			remetente.buscar( rs.getInt("cd_requisito_remetente") );
	
			setRemetente( remetente );
		}
		
		
		
		if (rs.getInt("cd_usuario_destinatario")!=0) {
			Usuario destinatario = new Usuario();
			destinatario.buscar( rs.getInt("cd_usuario_destinatario") );
			
			setDestinatario( destinatario );
		}
		
		if (rs.getInt("cd_requisito_destinatario")!=0) {
			Requisito destinatario = new Requisito();
			destinatario.buscar( rs.getInt("cd_requisito_destinatario") );
			
			setDestinatario( destinatario );
		}

		
		
		setAssunto( rs.getString("no_assunto") );
		setMensagem( rs.getString("mm_mensagem") );
		
		setLeitura( rs.getTimestamp("dh_leitura") );
	}

	
	
	



	public void gravar() {
		
		Database database = new Database();
		try {
			
			String sql = "insert into MENSAGEM (" +
					"DH_ENVIO, NO_ASSUNTO, " +
					"MM_MENSAGEM, " +
					"CD_USUARIO_DESTINATARIO, CD_USUARIO_REMETENTE, " +
					"CD_REQUISITO_DESTINATARIO, CD_REQUISITO_REMETENTE" +
					") values (?,?,?,?,?,?,?)";

			PreparedStatement pstmt = database.conn.prepareStatement( sql );
			
			pstmt.setTimestamp(1, getEnvio()==null? null : new Timestamp(getEnvio().getTime()) );
			pstmt.setString( 2, getAssunto() );
			pstmt.setString( 3, getMensagem() );
			
			// usuario
			pstmt.setObject( 4, getDestinatario() instanceof Usuario ? new Integer( getDestinatario().getId() ): null );
			pstmt.setObject( 5, getRemetente() instanceof Usuario ? new Integer( getRemetente().getId() ): null );
			
			// requisito
			pstmt.setObject( 6, getDestinatario() instanceof Requisito ? new Integer( getDestinatario().getId() ): null );
			pstmt.setObject( 7, getRemetente() instanceof Requisito ? new Integer( getRemetente().getId() ): null );
			
			pstmt.executeUpdate();
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
	}





	public static int contadorCaixaEntrada( Usuario destinatario ) {
		
		int contador=0;
		
		
		Database database = new Database();
		try {
			
			String sql = "select count (*) from " +
					"mensagem where ST_APAGADO_DESTINATARIO=0 and dh_leitura is null " +
					"and cd_usuario_destinatario=" + destinatario.getId();
	
			ResultSet rs = database.stmt.executeQuery(sql);
			
			while (rs.next()) {
	
				contador = rs.getInt(1);
				
			}
	
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return contador;
		
		
	}

	
	
	// TODO
	public static int contadorMensagensRequisitos( Usuario destinatario, Projeto projeto ) {
		
		int contador=0;
		
		
		Database database = new Database();
		try {
			
			
			String sql = 
				"select count(*) from mensagem m, requisito r " +
				" where ST_APAGADO_DESTINATARIO=0 and cd_requisito_destinatario=r.cd_requisito and " +
				"cd_projeto=" + projeto.getId() + " and cd_usuario= "+ destinatario.getId() + " " +
				"and ST_APAGADO_DESTINATARIO=0 and dh_leitura is null ";
	
			ResultSet rs = database.stmt.executeQuery(sql);
			
			while (rs.next()) {
	
				contador = rs.getInt(1);
				
			}
	
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
		return contador;
		
		
	}

	
	
	public void apagarRemetente() {
		
		Database database = new Database();
		try {
			
			String sql = "update MENSAGEM set st_apagado_remetente=1 where cd_mensagem=?";

			PreparedStatement pstmt = database.conn.prepareStatement( sql );
			
			pstmt.setInt( 1, getId() );

			pstmt.executeUpdate();
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
	}

	
	
	
	public void apagarDestinatario() {
		
		Database database = new Database();
		try {
			
			String sql = "update MENSAGEM set st_apagado_destinatario=1 where cd_mensagem=?";

			PreparedStatement pstmt = database.conn.prepareStatement( sql );
			
			pstmt.setInt( 1, getId() );

			pstmt.executeUpdate();
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
	}

	
	
	
	public void marcarComoLida() {
		
		Database database = new Database();
		try {
			
			String sql = "update MENSAGEM set dh_leitura=? where cd_mensagem=?";

			PreparedStatement pstmt = database.conn.prepareStatement( sql );
			
			pstmt.setTimestamp( 1, new Timestamp( (new Date()).getTime() ) );
			pstmt.setInt( 2, getId() );

			pstmt.executeUpdate();
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();		
		
		
	}

	
	
	
	public String getAssunto() {
		return assunto;
	}
	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}
	public DestinatarioRemetente getDestinatario() {
		return destinatario;
	}
	public void setDestinatario(DestinatarioRemetente destinatario) {
		this.destinatario = destinatario;
	}
	public Date getEnvio() {
		return envio;
	}
	public void setEnvio(Date envio) {
		this.envio = envio;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getLeitura() {
		return leitura;
	}
	public void setLeitura(Date leitura) {
		this.leitura = leitura;
	}
	public String getMensagem() {
		return mensagem;
	}
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
	public DestinatarioRemetente getRemetente() {
		return remetente;
	}
	public void setRemetente(DestinatarioRemetente remetente) {
		this.remetente = remetente;
	}
}
