package www;

import java.sql.*;
import java.util.*;

public class Risco {
	private int id;
	private String descricao="";
	private int peso;
	
	public Risco() {
	}
	
	
	public static String getHtmlCombo(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		String SQL = "SELECT cd_risco, mm_descricao FROM risco ORDER BY mm_descricao";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {                                
				html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return html.toString();
		
	}      
	
	public void cadastrar() {
		Database database = new Database();
		
		try {
			String SQL;
			
			int newId=0;
			SQL = "select max(cd_risco) from risco";
			ResultSet rs = database.stmt.executeQuery( SQL );
			if (rs.next()) {                              
				System.out.println( "ultimoid " + rs.getInt(1));
				newId = rs.getInt(1);
			}
			
			newId++;                        
			SQL = 
				"INSERT INTO risco (cd_risco, mm_descricao, vl_peso) VALUES (" + newId + ",'"+          
				descricao + "','"+peso  + "')";
			
			System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	public void alterar() {
		String SQL =
			"UPDATE risco set "+
			"mm_descricao='" + descricao + "',vl_peso='"+peso + "' where " +
			"cd_risco=" + getId();
		System.out.println(SQL);
		Database database = new Database();
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	
	public void excluir() throws Exception {
		
		String SQL = "DELETE FROM risco where cd_risco="+ getId();
		
		Database database = new Database();
		
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Erro ao apagar risco.");
			
		}
		database.fechar();
		
	}
	
	
	public static ArrayList buscaRisco(String trecho_nome, Pager pager) {
		
		String SQL =
			" FROM risco WHERE mm_descricao LIKE '%"+
			trecho_nome + "%' ";
		ArrayList retorno = new ArrayList();
		
		Database database = new Database();
		try {

		   int count = 0;
		   ResultSet rs = database.stmt.executeQuery("SELECT count(cd_risco) "+SQL);
		   while (rs.next()) {
		    count = rs.getInt(1);
		   }
		   
		   pager.setTotal(count);
		
		   rs = database.stmt.executeQuery( pager.formatSql("SELECT cd_risco "+SQL+" ORDER BY mm_descricao") );			
			while (rs.next()) {
				Risco r = new Risco();
				r.buscar(rs.getInt("cd_risco"));
				retorno.add(r);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	
	public void buscar(int cd) {
		String tempCD;
		tempCD = java.lang.Integer.toString(cd);
		String SQL =
			"SELECT * FROM risco WHERE cd_risco="+tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(cd);
				setDescricao(rs.getString("mm_descricao"));
				setPeso(rs.getInt("vl_peso"));
			}
			// System.out.println("fim");   
			
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	public static ArrayList listarTodos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_risco FROM risco ORDER BY mm_risco";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				A.add(new Integer(rs.getInt("cd_risco")));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	/*     public static String getHtmlCombo(int selected) {
	 
	 StringBuffer html = new StringBuffer();
	 
	 String SQL = "SELECT cd_usuario, no_usuario FROM usuario ORDER BY no_usuario";
	 
	 database.abrir_banco();
	 try {
	 
	 ResultSet rs = database.stmt.executeQuery(SQL);
	 while (rs.next()) {                                
	 html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
	 }
	 
	 } catch (java.lang.Exception erro) {
	 erro.printStackTrace();
	 }
	 database.fechar_banco();
	 return html.toString();
	 
	 }      */
	
	

	
	public static Risco getRiscoPadrao() {
		String SQL = "select first 1 cd_risco FROM risco";

		Risco m = null;
		
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				m = new Risco();
				m.buscar(rs.getInt("cd_risco"));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		
		return m;
	}
	
		
	
	/**
	 * @return Returns the descricao.
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao The descricao to set.
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the peso.
	 */
	public int getPeso() {
		return peso;
	}
	/**
	 * @param peso The peso to set.
	 */
	public void setPeso(int peso) {
		this.peso = peso;
	}
}