package www;

/**
 * <p>Title: ProjetoAlcada</p>
 * <p>Description: Projeto com Al�ada - para o usu�rio</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.sql.*;

public class ProjetoUsuario {
        
        Alcada alc;
        Usuario usr;
        Date inicio=null;
        Date cancelamento=null;

        
        public ProjetoUsuario (int cd_projeto, int cd_usuario, Date dt_inicio) throws Exception {
                
                
                String sql = "select cd_alcada, dt_cancelamento FROM projeto_usuario where cd_projeto="+ cd_projeto+" and cd_usuario="+cd_usuario+" and dt_inicio='" + dt_inicio + "' ";

                Database database = new Database();

                try {
                        ResultSet rs = database.stmt.executeQuery(sql);
                        
                        if (rs.next()) {
                                
                                alc = new Alcada();
                                alc.buscar( rs.getInt(1) );
                                
                                usr = new Usuario();
                                usr.buscar( cd_usuario );
                                
                                inicio=dt_inicio;
                                
                                cancelamento = rs.getDate(2);
                                                
                        }
                        
                } catch (java.lang.Exception erro) {
                        System.out.println(erro);
                        //      erro.printStackTrace();
                        throw new Exception("Erro ao apagar projeto");
                        
                }
                
                if (alc==null) throw new Exception("registro n�o encontrado!");
                
                database.fechar();
                
                
        }
        
        
        
        public Usuario getUsuario() {
                return usr;
        }
                
        public Alcada getAlcada() {
                return alc;
        }
                
 





        
		/**
		 * @return Returns the cancelamento.
		 */
		public Date getCancelamento() {
			return cancelamento;
		}
		/**
		 * @return Returns the inicio.
		 */
		public Date getInicio() {
			return inicio;
		}
}