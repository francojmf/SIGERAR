package www;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

public class Glossario {
	private int id;
	private String nome = "";
	private String descricao = "";
	private Date inicio = null;
	private Date cancelamento = null;
	
	
	public Glossario() {
	}
	
	
	
	
	public void cadastrar() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL;
			
			int newId=0;
			SQL = "select max(cd_glossario) from glossario";
			ResultSet rs = database.stmt.executeQuery( SQL );
			if (rs.next()) {
				newId = rs.getInt(1);
			}                        
			newId++;
			
			SQL =   "INSERT INTO glossario (cd_glossario, no_glossario, ds_glossario, dt_inicio) VALUES (" + newId + ",'"+
			getNome() + "','"+getDescricao() + "', current_date)";
			
//			System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar gloss�rio!");
		}
		database.fechar();
	}
	
	
	public void alterar() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL = "update glossario set no_glossario=?, ds_glossario=?, dt_inicio=?, dt_cancelamento=?  where cd_glossario=?";
			
			PreparedStatement pstmt = database.conn.prepareStatement( SQL );
			
			pstmt.setString(1, getNome());
			pstmt.setString(2, getDescricao());
			pstmt.setDate(3, getInicio()==null?null:new java.sql.Date(getInicio().getTime()));
			pstmt.setDate(4, getCancelamento()==null?null:new java.sql.Date(getCancelamento().getTime()));
			pstmt.setInt(5, getId());
			
			pstmt.execute();
			
			pstmt.close();
			
			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao alterar gloss�rio!");
		}
		database.fechar();
	}
	
	public void excluir() throws Exception {
		Database database = new Database();
		
		try {
			
			String SQL = "delete from glossario where cd_glossario=" + getId() ;
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Problemas ao cadastrar gloss�rio!");
		}
		database.fechar();
	}
	
	
	
	public void relacionar_termo(Termo p) {
		String SQL =
			"INSERT INTO glossario_termo (cd_glossario, cd_termo) VALUES ("+
			getId() + ","+p.getId() + ")";
		Database database = new Database();
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	public static ArrayList busca(String trecho_nome) {
		String SQL =
			"SELECT cd_glossario FROM glossario WHERE no_glossario LIKE '%"+
			trecho_nome + "%' ORDER BY no_glossario";
		ArrayList retorno = new ArrayList();
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				Glossario g = new Glossario();
				g.buscar(rs.getInt("cd_glossario"));
				retorno.add(g);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	public void buscar(int cd) {
		String tempCD;
		tempCD = Integer.toString(cd);
		String SQL = "SELECT * FROM glossario WHERE cd_glossario="+tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId(cd);
				setNome(rs.getString("no_glossario"));
				setDescricao(rs.getString("ds_glossario"));
				setInicio(rs.getDate("dt_inicio"));
				setCancelamento(rs.getDate("dt_cancelamento"));
			}
		}
		catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	public static ArrayList listar_todos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_glossario FROM glossario ORDER BY no_glossario";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				A.add(new Integer(rs.getInt("cd_glossario")));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	

	
	public String marcarTermos(String retorno) {
		
		ArrayList termos = Termo.listarTodos(getId());
		
		for (int i=0; i<termos.size(); i++) {
			Termo termo = (Termo)termos.get(i);
			
			retorno = Util.replace( retorno, termo.getNome(), "<a href=\"javascript:buscaTermo("+termo.getId()+")\" class=\"termo\">" + termo.getNome() + "</a>");
			
		}

		return retorno;
	}
	
	
	
	/**
	 * @return Returns the cancelamento.
	 */
	public Date getCancelamento() {
		return cancelamento;
	}
	/**
	 * @param cancelamento The cancelamento to set.
	 */
	public void setCancelamento(Date cancelamento) {
		this.cancelamento = cancelamento;
	}
	/**
	 * @return Returns the descricao.
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao The descricao to set.
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return Returns the nome.
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome The nome to set.
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the inicio.
	 */
	public Date getInicio() {
		return inicio;
	}
	/**
	 * @param inicio The inicio to set.
	 */
	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}




}