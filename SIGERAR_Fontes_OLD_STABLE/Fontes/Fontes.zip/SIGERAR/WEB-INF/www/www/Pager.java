/*
 * Created on 01/10/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package www;

import java.util.LinkedList;


/**
 * @author marcelo
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Pager {

	// o usuario entra
	private int total = 0;
	private int paginaAtual = 0;
	private int linhasPorPagina = 0;
	// � calculado
	private int totalPaginas = 0;
	private int linhasNestaPagina = 0;
	private int registroInicial = 0;
	private int registroFinal = 0;

	private int paginaSeguinte = 0;
	private int paginaAnterior = 0;

	
	
	public void calcular() {
		
		// s� calcula quanto tiver todas as vari�veis:
		if (paginaAtual>0 && linhasPorPagina>0) {
		
			// c�lculo
			int mod = total % linhasPorPagina;
			totalPaginas = total / linhasPorPagina;
			if(mod != 0) {
				totalPaginas++;
			}

			linhasNestaPagina = linhasPorPagina;

			if (paginaAtual > totalPaginas) paginaAtual = totalPaginas; 
			
			if (totalPaginas == paginaAtual) {
				linhasNestaPagina = total - (linhasPorPagina*(totalPaginas-1));
			}
			
			registroInicial = linhasPorPagina * (paginaAtual - 1) + 1;
			
			registroFinal = registroInicial - 1 + linhasNestaPagina;
		
			if (paginaAtual==totalPaginas) {
				paginaSeguinte = -1;
			} else {
				paginaSeguinte = paginaAtual+1;
			}
				
			if (paginaAtual==1) {
				paginaAnterior = -1;
			} else {
				paginaAnterior = paginaAtual-1;
			}
			
		}
		
	}
	
    public LinkedList getPaginasProximas( ) {

    	LinkedList lista = new LinkedList();
        
        int inicio = getPaginaAtual() - 5;
        int fim = getPaginaAtual() + 5;
        
        if (inicio < 1) inicio = 1;
        if (fim > getTotalPaginas()) fim = getTotalPaginas();
        
        for (int i=inicio; i<=fim; i++) {
        	lista.add( new Integer(i) );
        }
        
        return lista;

    }

    
    
    public String formatSql( String sql ) {
    	
    	int pos = sql.toLowerCase().indexOf("select");
    	
    	return sql.substring(0,pos+6) + " first "+ getLinhasNestaPagina() +" skip "+ (getRegistroInicial()-1>0?getRegistroInicial()-1:0) +" "+ sql.substring(pos+6, sql.length());
    	/*
    	return "select  * from (" +
    			"select x.*, rownum as linha from ( " +
    			sql +
    			") x where rownum > 0" +
    			") where linha between " + getRegistroInicial() + " and " + getRegistroFinal();
    			*/
    }
	
	
	
	/**
	 * @return Returns the linhasPorPagina.
	 */
	public int getLinhasPorPagina() {
		return linhasPorPagina;
	}
	/**
	 * @param linhasPorPagina The linhasPorPagina to set.
	 */
	public void setLinhasPorPagina(int linhasPorPagina) {
		this.linhasPorPagina = linhasPorPagina;
		//calcular();
	}
	/**
	 * @return Returns the paginaAtual.
	 */
	public int getPaginaAtual() {
		return paginaAtual;
	}
	/**
	 * @param paginaAtual The paginaAtual to set.
	 */
	public void setPaginaAtual(int paginaAtual) {
		this.paginaAtual = paginaAtual;
		//calcular();
	}
	/**
	 * @return Returns the total.
	 */
	public int getTotal() {
		return total;
	}
	/**
	 * @param total The total to set.
	 */
	public void setTotal(int total) {
		this.total = total;
		calcular();
	}
	
	/**
	 * @return Returns the totalPaginas.
	 */
	public int getTotalPaginas() {
		return totalPaginas;
	}
	/**
	 * @return Returns the registroFinal.
	 */
	public int getRegistroFinal() {
		return registroFinal;
	}
	
	public int getRegistroInicial() {
	/**
	 * @return Returns the registroInicial.
	 */
		return registroInicial;
	}

	/**
	 * @return Returns the linhasNestaPagina.
	 */
	public int getLinhasNestaPagina() {
		return linhasNestaPagina;
	}

	
	/**
	 * @return Returns the paginaAnterior.
	 */
	public int getPaginaAnterior() {
		return paginaAnterior;
	}
	/**
	 * @return Returns the paginaSeguinte.
	 */
	public int getPaginaSeguinte() {
		return paginaSeguinte;
	}
}
