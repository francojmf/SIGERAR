package www;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.sql.ResultSet;
import java.util.ArrayList;

public class Termo {
        private int id;
        private int idGlossario;
        private String nome = "";
        private String descricao = "";

        public Termo() {
        }

        public void cadastrar() throws Exception {
            Database database = new Database();

                try {
                        String SQL;
                        
                        int newId=0;
                                SQL = "select max(cd_termo) from termo";
                        ResultSet rs = database.stmt.executeQuery( SQL );
                        if (rs.next()) {
                                
                                newId = rs.getInt(1);
                        }
                        
                        newId++;
                        
                        SQL =   "INSERT INTO termo (cd_termo, cd_glossario, no_termo, ds_termo) VALUES (" + newId + ","+
                                getIdGlossario() + ",'" + getNome() + "','"+ getDescricao()+ "')";

//                        System.out.println(SQL);

                        database.stmt.execute(SQL);
                } catch (java.lang.Exception erro) {
                        System.out.println(erro);
                        //      erro.printStackTrace();
                        throw new Exception("Problemas ao cadastrar gloss�rio!");
                }
                database.fechar();
        }
  
        public void alterar() throws Exception {
            Database database = new Database();

                try {

                        String SQL = "update termo set no_termo='"+
                                        getNome() + "',ds_termo='"+ getDescricao() + "' where cd_termo=" + getId();

//                        System.out.println(SQL);

                        database.stmt.execute(SQL);
                } catch (java.lang.Exception erro) {
                        System.out.println(erro);
                        //      erro.printStackTrace();
                        throw new Exception("Problemas ao cadastrar gloss�rio!");
                }
                database.fechar();
        }



      public void excluir() throws Exception {
          Database database = new Database();

                try {

                        String SQL = "delete from termo where cd_termo=" + getId() ;

                        database.stmt.execute(SQL);
                } catch (java.lang.Exception erro) {
                        System.out.println(erro);
                        //      erro.printStackTrace();
                        throw new Exception("Problemas ao cadastrar termo!");
                }
                database.fechar();
        }
        
      
        public static ArrayList buscaTermos(String trecho_nome, int cd_glossario, Pager pager) {

            ArrayList retorno = new ArrayList();
            Database database = new Database();
            try {

            	String SQL =
	                " FROM termo WHERE (no_termo LIKE '%"+
	                trecho_nome + "%' or ds_termo LIKE '%"+
	                trecho_nome + "%') and cd_glossario=" + cd_glossario + " ";
        	
        	   int count = 0;
        	   ResultSet rs = database.stmt.executeQuery("SELECT count(cd_termo) "+SQL);
        	   while (rs.next()) {
        	    count = rs.getInt(1);
        	   }
        	   
        	   pager.setTotal(count);

//        	   System.out.println( pager.formatSql("SELECT cd_termo "+SQL+" ORDER BY no_termo") );
        	   rs = database.stmt.executeQuery( pager.formatSql("SELECT cd_termo "+SQL+" ORDER BY no_termo") );
        	   
                        while (rs.next()) {
                    		Termo t = new Termo();
                    		t.buscar(rs.getInt("cd_termo"));
                            retorno.add(t);
                        }
                } catch (java.lang.Exception erro) {
                        erro.printStackTrace();
                }
                database.fechar();
                return retorno;
        }

        
        
        public void buscar(int cd) {
                String tempCD;
                tempCD = Integer.toString(cd);
                String SQL = "SELECT * FROM termo WHERE cd_termo="+
                        tempCD;
                Database database = new Database();
                try {
                        ResultSet rs = database.stmt.executeQuery(SQL);
                        if (rs.next()) {
                                setId(cd);
                                setNome(rs.getString("no_termo"));
                                setDescricao(rs.getString("ds_termo"));
                                setIdGlossario(rs.getInt("cd_glossario"));
                        }
                        //System.out.println("fim");
                }
                catch (java.lang.Exception erro) {
                        erro.printStackTrace();
                }
                database.fechar();
        }

        public static ArrayList listarTodos( int cd_glossario ) {
                ArrayList A = new ArrayList();
                String SQL = "SELECT cd_termo FROM termo where cd_glossario=" + cd_glossario + " ORDER BY no_termo";
                Database database = new Database();
                try {
                        ResultSet rs = database.stmt.executeQuery(SQL);
                        while (rs.next()) {
                        	Termo t = new Termo();
                        	t.buscar(rs.getInt("cd_termo"));
                            A.add(t);
                        }
                } catch (java.lang.Exception erro) {
                        erro.printStackTrace();
                }
                database.fechar();
                return A;
        }
        
        
		/**
		 * @return Returns the descricao.
		 */
		public String getDescricao() {
			return descricao;
		}
		/**
		 * @param descricao The descricao to set.
		 */
		public void setDescricao(String descricao) {
			this.descricao = descricao;
		}
		/**
		 * @return Returns the id.
		 */
		public int getId() {
			return id;
		}
		/**
		 * @param id The id to set.
		 */
		public void setId(int id) {
			this.id = id;
		}
		/**
		 * @return Returns the idGlossario.
		 */
		public int getIdGlossario() {
			return idGlossario;
		}
		/**
		 * @param idGlossario The idGlossario to set.
		 */
		public void setIdGlossario(int idGlossario) {
			this.idGlossario = idGlossario;
		}
		/**
		 * @return Returns the nome.
		 */
		public String getNome() {
			return nome;
		}
		/**
		 * @param nome The nome to set.
		 */
		public void setNome(String nome) {
			this.nome = nome;
		}
}