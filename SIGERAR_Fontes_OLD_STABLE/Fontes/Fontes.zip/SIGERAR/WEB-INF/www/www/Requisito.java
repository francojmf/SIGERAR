package www;

import www.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public class Requisito implements DestinatarioRemetente {
	private int id;
	private int idTipo;
	private int idVolatilidade;
	private String nome="";
	private int idUsuario;
	private int idProjeto;
	
	private int ordem;
	private String codigoCompleto;
	private int idRequisitoPai;
	
	private int sub;
	
	private Date dtCancelamento;
	
	
	public ArrayList requisitosAlocados=new ArrayList();
	
	
	
	public Requisito() {
	}                  
	
	public static String getHtmlCombo(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		String SQL = "SELECT cd_requisito, no_requisito FROM requisito ORDER BY no_requisito";
		
		Database database = new Database();
		try {
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {                                
				html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return html.toString();
		
	}      
	/*
	 public String getTipo() {         
	 TipoRequisito tipo = new TipoRequisito();
	 tipo.buscar(getIdTipo());                
	 return tipo.getNome();
	 } 
	 */
	public void cadastrar() {
		
		Database database = new Database();
		
		try {
			String SQL = 
				"INSERT INTO requisito (no_requisito, cd_tipo, cd_volatilidade, cd_usuario, cd_projeto, cd_requisito_pai) " +
				"VALUES ('"+
				getNome() + "',"+ getIdTipo() + ",'"+ getIdVolatilidade() +
				"','"+ getIdUsuario() + "','"+getIdProjeto() + "', " + (getIdRequisitoPai()==0?"null":""+getIdRequisitoPai()) + ")";
			
			System.out.println(SQL);
			
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	public void alterar() {
		String SQL =
			"UPDATE requisito set "+
			"no_requisito='" + getNome() + "',cd_tipo="+ getIdTipo() + ",cd_volatilidade='"+getIdVolatilidade() +
			"',cd_usuario='"+ getIdUsuario() + "', " +
			"dt_cancelamento="  + (getDtCancelamento()==null?"null":"'"+ new java.sql.Date(getDtCancelamento().getTime()) + "'")  + " " +
			"where " +
			"cd_requisito=" + getId();
		System.out.println(SQL);
		Database database = new Database();
		
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	
	
	public void excluir() throws Exception {
		
		
		Database database = new Database();
		
		try {
			
			String SQL = "DELETE FROM requisito where cd_requisito_pai="+ getId();
			database.stmt.execute(SQL);
			
			SQL = "DELETE FROM requisito where cd_requisito="+ getId();
			database.stmt.execute(SQL);
			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Erro ao apagar requisito.");
			
		}
		database.fechar();
		
	}
	
	
	
	/*
	 public static ArrayList busca_esp(String trecho_nome) {
	 String SQL =
	 "SELECT cd_requisito FROM requisito WHERE no_requisito LIKE '%"+
	 trecho_nome + "%' ORDER BY no_requisito";
	 ArrayList retorno = new ArrayList();
	 Database database = new Database();
	 try {
	 ResultSet rs = database.stmt.executeQuery(SQL);
	 while (rs.next()) {
	 retorno.add(rs.getObject("cd_requisito"));
	 }
	 } catch (java.lang.Exception erro) {
	 erro.printStackTrace();
	 }
	 database.fechar();
	 return retorno;
	 }
	 
	 */
	
	void preencher( ResultSet rs ) throws SQLException {
		setId( rs.getInt("cd_requisito") );
		setOrdem( rs.getInt("nr_ordem") );
		setCodigoCompleto( rs.getString("cd_completo") );
		setIdRequisitoPai( rs.getInt("cd_requisito_pai") );
		setIdTipo(rs.getInt("cd_tipo"));
		setNome(rs.getString("no_requisito"));
		setIdVolatilidade(rs.getInt("cd_volatilidade"));
		setIdUsuario(rs.getInt("cd_usuario"));
		setIdProjeto(rs.getInt("cd_projeto"));
		setDtCancelamento(rs.getTimestamp("dt_cancelamento"));
		
		setSub( rs.getInt("sub") );
		
	}
	
	public void buscar(int cd) {
		
		String SQL =
			"SELECT r.*, (select count(*) from requisito where cd_requisito_pai=r.cd_requisito and r.dt_cancelamento is not null) sub FROM requisito r WHERE cd_requisito="+cd;
		
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				preencher( rs );
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	/*
	 public void total(int cd) {
	 String tempCD;
	 tempCD = java.lang.Integer.toString(cd);
	 String SQL =
	 "select max(cd_requisito) from requisito WHERE cd_requisito="+tempCD;
	 Database database = new Database();
	 try {
	 ResultSet rs = database.stmt.executeQuery(SQL);
	 if (rs.next()) {
	 setId(cd);
	 }
	 } catch (java.lang.Exception erro) {
	 erro.printStackTrace();
	 }
	 database.fechar();
	 }
	 */
	
	public static ArrayList listarRequisitos( Projeto p, int pai ) {
		ArrayList A = new ArrayList();
		String SQL = "SELECT r.*, (select count(*) from requisito where cd_requisito_pai=r.cd_requisito and r.dt_cancelamento is not null) sub FROM requisito r where cd_projeto=" + p.getId() + " and cd_requisito_pai" + (pai==0?" is null":" = "+pai) + " ORDER BY nr_ordem";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				Requisito req = new Requisito();
				req.preencher( rs );
				A.add(req);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	

	
	public static ArrayList listarRequisitosDaPessoa( Projeto p, Usuario responsavel ) {
		ArrayList A = new ArrayList();
		String SQL = "SELECT r.*, " +
				"(select count(*) from requisito where cd_requisito_pai=r.cd_requisito and r.dt_cancelamento is not null) sub " +
				"FROM requisito r where cd_projeto=" + p.getId() + " and cd_usuario= "+ responsavel.getId() + " ORDER BY cd_completo";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				Requisito req = new Requisito();
				req.preencher( rs );
				A.add(req);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	

	
	
	public static ArrayList listarRequisitosDaPessoaComMensagem( Projeto p, Usuario responsavel ) {
		ArrayList A = new ArrayList();
		String SQL = "SELECT r.*, " +
				"(select count(*) from requisito where cd_requisito_pai=r.cd_requisito and r.dt_cancelamento is not null) sub, " +
				"(select count(*) from mensagem where cd_requisito_destinatario=r.cd_requisito and dh_leitura is null) msg " +
				"FROM requisito r where cd_projeto=" + p.getId() + " and cd_usuario= "+ responsavel.getId() + " and dt_cancelamento is null ORDER BY cd_completo";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				RequisitoMensagem req = new RequisitoMensagem();
				req.preencher( rs );
				req.setQtde( rs.getInt("msg") );
				A.add(req);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	

	
	
	public static void listarArvoreRequisitos( Projeto p, int pai, ArrayList lista, int nivel ) {
		String SQL = "SELECT r.*, (select count(*) from requisito where cd_requisito_pai=r.cd_requisito and dt_cancelamento is null) sub FROM requisito r where cd_projeto=" + p.getId() + " and cd_requisito_pai" + (pai==0?" is null":" = "+pai) + " ORDER BY nr_ordem";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				RequisitoArvore req = new RequisitoArvore();
				req.preencher( rs );
				req.setNivel( nivel );
				lista.add(req);
				listarArvoreRequisitos( p, req.getId(), lista, nivel+1);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
/* adicionada para filtro e ainda nao esta pronto*/
/*	public static void listarArvoreRequisitos( Projeto p, int pai, ArrayList lista, int nivel, String iTipo, String iUsuario, String status) {
		String SQL = "SELECT r.*, (select count(*) from requisito where cd_requisito_pai=r.cd_requisito and dt_cancelamento is null) sub FROM requisito r where cd_projeto=" + p.getId() + " and cd_requisito_pai" + (pai==0?" is null":" = "+pai) + " ORDER BY nr_ordem";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				RequisitoArvore req = new RequisitoArvore();
				req.preencher( rs );
				req.setNivel( nivel );
				lista.add(req);
				listarArvoreRequisitos( p, req.getId(), lista, nivel+1);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
*/
	
	
	/*
	 public static ArrayList listar() {
	 ArrayList A = new ArrayList();
	 String SQL = "SELECT cd_requisito FROM requisito where st_interno=0 ORDER BY no_requisito";
	 Database database = new Database();
	 try {
	 ResultSet rs = database.stmt.executeQuery(SQL);
	 while (rs.next()) {
	 Requisito req = new Requisito();
	 req.buscar( rs.getInt("cd_requisito") );
	 A.add( req );
	 }
	 } catch (java.lang.Exception erro) {
	 erro.printStackTrace();
	 }
	 database.fechar();
	 return A;
	 }
	 */
	
	
	public void cadastrarDependencias( String[] ids ) {
		Database database = new Database();
		try {
			String SQL =
				"delete from requisito_dependente where cd_requisito = " + getId();
			database.stmt.execute(SQL);
			
			for (int i=0; i<ids.length; i++) {
				
				SQL = "insert into requisito_dependente (cd_requisito, cd_requisito_superior) values (" + getId() + "," + ids[i] + ")";
				database.stmt.execute(SQL);
				
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	public void adicionarDependencias( String[] ids ) {
		Database database = new Database();
		try {
			
			for (int i=0; i<ids.length; i++) {
				
				String SQL = "insert into requisito_dependente (cd_requisito, cd_requisito_superior) values (" + getId() + "," + ids[i] + ")";
				database.stmt.execute(SQL);
				
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	public boolean isDependenteDe( Requisito r ) {
		
		
		boolean dependenteDe = false;
		
		Database database = new Database();
		
		try {
			String SQL = 
				"select count(*) from requisito_dependente where " +
				"cd_requisito=" + getId() + " and cd_requisito_superior=" + r.getId();
			
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				dependenteDe = rs.getInt(1)>0;
			}
			
			rs.close();
			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
		
		return dependenteDe;
	}
	
	
	
	public static ArrayList listarRequisitosDependentes( Requisito r ) {
		ArrayList A = new ArrayList();
		String SQL = "select r.*, (select count(*) from requisito where cd_requisito_pai=r.cd_requisito and r.dt_cancelamento is not null) sub from requisito_dependente rd, requisito r " +
		"where rd.cd_requisito = r.cd_requisito " +
		"and rd.cd_requisito_superior=" + r.getId();
		
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				Requisito req = new Requisito();
				req.preencher( rs );
				A.add(req);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	
	public VersaoRequisito getNovaVersao( Usuario solicitante ) {
		
		VersaoRequisito vr = VersaoRequisito.getUltimaVersao( this );
		VersaoRequisito novaVR = new VersaoRequisito();
		
		novaVR.setDataSolicitacao( new Date() );
		
		novaVR.setIdRequisito( this.getId() );

		novaVR.setIdUsuarioSolicitante( solicitante.getId() );
		
		novaVR.setId( vr==null?1:vr.getId()+1 );
		
		novaVR.setIdUsuarioResponsavel( getIdUsuario() );


		if (vr==null)
			novaVR.setIdMotivo( Motivo.getMotivoInclusao().getId() );
		else 
			novaVR.setIdMotivo( Motivo.getMotivoPadrao().getId() );

		novaVR.setCusto( 0 );

		if (vr!=null) {
			
			novaVR.setDescricao( vr.getDescricao() );
			novaVR.setIdImpacto( vr.getIdImpacto() );
			novaVR.setIdImportancia( vr.getIdImportancia() );
			novaVR.setIdRisco( vr.getIdRisco() );
			novaVR.setPrioridade( vr.getPrioridade() );
			
		} else {

			// TODO: padroes 
			novaVR.setIdImpacto( Impacto.getImpactoPadrao().getId() );
			novaVR.setIdImportancia( Importancia.getImportanciaPadrao().getId() );
			novaVR.setIdRisco( Risco.getRiscoPadrao().getId() );
			
			
		}
		
		novaVR.setSituacao( VersaoRequisito.SITUACAO_PROPOSTA );
		
		return novaVR;
				
	}
	
	
	/*  public static String getHtmlCombo(int selected) {
	 
	 StringBuffer html = new StringBuffer();
	 
	 String SQL = "SELECT cd_usuario, no_usuario FROM usuario ORDER BY no_usuario";
	 
	 database.abrir_banco();
	 try {
	 
	 ResultSet rs = database.stmt.executeQuery(SQL);
	 while (rs.next()) {                                
	 html.append( "<option value='" + rs.getString(1) + "' " + (selected==rs.getInt(1)?"selected":"") + ">" + rs.getString(2) + "</option>" );
	 }
	 
	 } catch (java.lang.Exception erro) {
	 erro.printStackTrace();
	 }
	 database.fechar_banco();
	 return html.toString();
	 
	 }      */
	
	
	public boolean equals (Object o ) {
		
		return (
				o instanceof Requisito
				&&
				((Requisito)o).getId() == getId()
				);
		
	}
	
	
		
	/** para implementar DestinatarioRemetente **/
	public String getDescricao() {
		return getCodigoCompleto() + " - " + getNome();
	}
	
	
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the idProjeto.
	 */
	public int getIdProjeto() {
		return idProjeto;
	}
	/**
	 * @param idProjeto The idProjeto to set.
	 */
	public void setIdProjeto(int idProjeto) {
		this.idProjeto = idProjeto;
	}
	public String getCodigoCompleto() {
		return codigoCompleto;
	}
	public void setCodigoCompleto(String codigoCompleto) {
		this.codigoCompleto = codigoCompleto;
	}
	public int getIdRequisitoPai() {
		return idRequisitoPai;
	}
	public void setIdRequisitoPai(int idRequisitoPai) {
		this.idRequisitoPai = idRequisitoPai;
	}
	public int getOrdem() {
		return ordem;
	}
	public void setOrdem(int ordem) {
		this.ordem = ordem;
	}
	/**
	 * @return Returns the idTipo.
	 */
	public int getIdTipo() {
		return idTipo;
	}
	public TipoRequisito getTipo() {
		TipoRequisito tr = new TipoRequisito();
		tr.buscar( getIdTipo() );
		return tr;
	}
	/**
	 * @param idTipo The idTipo to set.
	 */
	public void setIdTipo(int idTipo) {
		this.idTipo = idTipo;
	}
	/**
	 * @return Returns the idUsuario.
	 */
	public int getIdUsuario() {
		return idUsuario;
	}
	public Usuario getUsuario() {
		Usuario u = new Usuario();
		u.buscar( getIdUsuario() );
		return u;
	}
	/**
	 * @param idUsuario The idUsuario to set.
	 */
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	/**
	 * @return Returns the idVolatilidade.
	 */
	public int getIdVolatilidade() {
		return idVolatilidade;
	}
	public Volatilidade getVolatilidade() {
		Volatilidade v = new Volatilidade();
		v.buscar( getIdVolatilidade() );
		return v;
	}
	/**
	 * @param idVolatilidade The idVolatilidade to set.
	 */
	public void setIdVolatilidade(int idVolatilidade) {
		this.idVolatilidade = idVolatilidade;
	}
	/**
	 * @return Returns the nome.
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome The nome to set.
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * @return Returns the requisitosAlocados.
	 */
	public ArrayList getRequisitosAlocados() {
		return requisitosAlocados;
	}
	/**
	 * @param requisitosAlocados The requisitosAlocados to set.
	 */
	public void setRequisitosAlocados(ArrayList requisitosAlocados) {
		this.requisitosAlocados = requisitosAlocados;
	}
	public int getSub() {
		return sub;
	}
	public void setSub(int sub) {
		this.sub = sub;
	}
	public Date getDtCancelamento() {
		return dtCancelamento;
	}
	public void setDtCancelamento(Date dtCancelamento) {
		this.dtCancelamento = dtCancelamento;
	}
}