package www;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.StringTokenizer;

public class Projeto {
	private int id;
	private int idGerente;
	private String nome="";
	private String descricao="";
	private Date inicio = null;
	private Date cancelamento = null;
	
	
	public ArrayList glossariosAlocados=new ArrayList();
	
	
	
	public Projeto() {
	}
	
	public String getGerente() 
	{                 
		Usuario us = new Usuario();
		us.buscar(getIdGerente());
		
		return us.getNome();                      
	}   
	
	public void cadastrar() {
		
		Database database = new Database();
		
		try {
			
			String SQL;
			
			int newId=0;
			SQL = "select max(cd_projeto) from projeto";
			ResultSet rs = database.stmt.executeQuery( SQL );
			if (rs.next()) {
				newId = rs.getInt(1);
			}
			
			newId++;
			
			SQL = 
				"INSERT INTO projeto (cd_projeto, no_projeto, ds_projeto, cd_gerente, dt_inicio) VALUES (" + newId + ",'"+
				getNome() + "','"+ getDescricao() + "',"+getIdGerente() + ", current_date)";
			
			database.stmt.execute(SQL);
			
			setId(newId);
			
			gravaGlossariosAlocados();
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}        
	
	
	public void alterar() {
		/*
		 String SQL =
		 "UPDATE projeto set "+
		 "no_projeto='" + nome + "',ds_projeto='"+descricao + "',cd_gerente="+cd_gerente  + ",ds_projeto='"+descricao + "',dt_inicio=" + (inicio.equals("")?"null":"'"+inicio+"'") + ",dt_cancelamento=" + (cancelamento.equals("")?"null":"'"+cancelamento+"'") + " where " +
		 "cd_projeto=" + getId();
		 */
		Database database = new Database();
		try {
			
			String SQL =
				"UPDATE projeto set no_projeto=?, ds_projeto=?," +
				"cd_gerente=?,dt_inicio=?,dt_cancelamento=? where " +
				"cd_projeto=?";
			
			PreparedStatement pstmt = database.conn.prepareStatement(SQL);
			
			
			pstmt.setString(1, getNome());
			pstmt.setString(2, getDescricao());
			pstmt.setInt(3, getIdGerente());
			pstmt.setDate(4, getInicio()==null?null:new java.sql.Date( getInicio().getTime() ));
			//			System.out.println(getCancelamento());
			pstmt.setDate(5, getCancelamento()==null?null:new java.sql.Date( getCancelamento().getTime() ));
			pstmt.setInt(6, getId());
			
			pstmt.executeUpdate();
			
			gravaGlossariosAlocados();
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
	}
	
	void gravaGlossariosAlocados() {
		
		Database database = new Database();
		try {
			
			database.stmt.execute("delete from projeto_glossario where cd_projeto=" + getId());
			
			for (int i=0; i<glossariosAlocados.size(); i++) {
				
				Glossario g = (Glossario)glossariosAlocados.get(i);
				
				String sql = "insert into projeto_glossario(cd_projeto,cd_glossario) values ("+getId()+", "+g.getId()+")";
				
				database.stmt.execute(sql);
			}
			
			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
		}
		database.fechar();
		
	}
	
	
	
	
	public void excluir() throws Exception {
		
		String SQL = "DELETE FROM projeto where cd_projeto="+ getId();
		
		Database database = new Database();
		
		try {
			database.stmt.execute(SQL);
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//      erro.printStackTrace();
			throw new Exception("Erro ao apagar projeto");
			
		}
		database.fechar();
		
	}
	
	
	public static ArrayList busca(String trecho_nome, Pager pager) {
		
		String SQL =  " FROM projeto WHERE no_projeto LIKE '%"+
		trecho_nome + "%'";
		
		ArrayList retorno = new ArrayList();
		Database database = new Database();
		try {
			
			int count = 0;
			ResultSet rs = database.stmt.executeQuery("SELECT count(cd_projeto) "+SQL);
			while (rs.next()) {
				count = rs.getInt(1);
			}
			
			pager.setTotal(count);
			
//			System.out.println(pager.formatSql("SELECT cd_projeto "+SQL+" ORDER BY no_projeto"));
			
			rs = database.stmt.executeQuery( pager.formatSql("SELECT cd_projeto "+SQL) );
			while (rs.next()) {
				Projeto p = new Projeto();
				p.buscar(rs.getInt("cd_projeto"));
				retorno.add(p);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	public void buscar(int cd) {
		String tempCD;
		tempCD = java.lang.Integer.toString(cd);
		String SQL = "SELECT * FROM projeto WHERE cd_projeto="+tempCD;
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			if (rs.next()) {
				setId( cd );
				setNome( rs.getString("no_projeto") );
				setDescricao( rs.getString("ds_projeto") );
				setIdGerente(rs.getInt("cd_gerente"));
				inicio = rs.getDate("dt_inicio");
				cancelamento = rs.getDate("dt_cancelamento");
			}
			atualizarGlossariosAlocados();
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
	}
	
	
	public static ArrayList listarTodos() {
		ArrayList A = new ArrayList();
		String SQL = "SELECT cd_projeto FROM projeto ORDER BY no_projeto";
		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				A.add(rs.getObject("cd_projeto"));
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	void atualizarGlossariosAlocados() {
		
		glossariosAlocados=new ArrayList();
		
		String SQL = "select g.cd_glossario " +
		"from projeto_glossario pg, glossario g " +
		"where pg.cd_glossario = g.cd_glossario " +
		"and g.dt_cancelamento is null " +
		"and pg.cd_projeto=" + getId() +
		" order by g.no_glossario";

		Database database = new Database();
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				
				Glossario g = new Glossario();
				g.buscar( rs.getInt("cd_glossario") );
				glossariosAlocados.add(g);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		
	}
	
	
	/*
	 * Este m�todo espera uma string no formato string1,string2,(...)stringn
	 */
	
	public void setGlossariosAlocados(String glossarios) {
		
		try {
			glossariosAlocados = new ArrayList();
			
			StringTokenizer st = new StringTokenizer(glossarios, ",");
			while (st.hasMoreTokens()) {
				Glossario g = new Glossario();
				g.buscar(Integer.parseInt( st.nextToken() ));
				
				glossariosAlocados.add(g);
			}
			
		} catch (Exception e) { }
	}
	
	
	public ArrayList listarGlossariosAlocados() {
		return glossariosAlocados;
	}
	
	
	
	public ArrayList listarGlossariosNaoAlocados() {                
		ArrayList alocados = listarGlossariosAlocados();
		
		ArrayList A = new ArrayList();
		String SQL = "select g.cd_glossario " +
		"from glossario g " +
		"where g.dt_cancelamento is null ";
		
		
		for (int i=0;i<alocados.size();i++) {
			Glossario g = (Glossario)alocados.get(i);
			//if (i==0) {
			//        SQL+=" where ";
			//} else {
			SQL+=" and ";
			//}
			
			SQL += " cd_glossario<>" + g.getId() + " ";
		}
		
		SQL += " order by g.no_glossario ";
		
		Database database = new Database();
		
		try {
			ResultSet rs = database.stmt.executeQuery(SQL);
			while (rs.next()) {
				Glossario g = new Glossario();
				g.buscar( rs.getInt("cd_glossario") );
				A.add(g);
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return A;
	}
	
	
	
	
	public String getHtmlComboResponsavel(int selected) {
		
		StringBuffer html = new StringBuffer();
		
		//adicionar gerente
		Usuario gerente = new Usuario();
		gerente.buscar( getIdGerente() );
		html.append( "<option value='" + gerente.getId() + "' " + (selected==gerente.getId()?"selected":"") + ">" + gerente.getNome() + "</option>" );
		
		// adicionar usu�rios
		boolean achou = false;
		
		ArrayList lista = listarUsuariosAlocados(false);
		for (int i=0; i<lista.size(); i++) {
			ProjetoUsuario pu = (ProjetoUsuario)lista.get(i);
			
			if (pu.getAlcada().temPermissao("RESP_POR_REQUISITO")) 
				html.append( "<option value='" + pu.getUsuario().getId() + "' " + (selected==pu.getUsuario().getId()?"selected":"") + ">" + pu.getUsuario().getNome() + "</option>" );
			
			if (selected==pu.getUsuario().getId()) achou=true;
		}
		
		// se n�o achou, � outra pessoa, coloca esta tbm.
		if (selected!=gerente.getId() && !achou) {
			Usuario resp = new Usuario();
			resp.buscar( selected );
			html.append( "<option value='" + resp.getId() + "' selected>" + resp.getNome() + "</option>" );
		}
		
		return html.toString();
		
	}      
	
	public ArrayList listarUsuariosAlocados( boolean mostraCancelados) {
		
		ArrayList retorno = new ArrayList();
		
		String sql = "select pu.cd_usuario, pu.dt_inicio " +
		"from projeto_usuario pu, usuario u " +
		"where pu.cd_usuario=u.cd_usuario and cd_projeto=" + getId() + 
		(mostraCancelados?"":" and pu.dt_cancelamento is null ") +
		" order by u.no_usuario";
		
		
		Database database = new Database();
		
		try {
			ResultSet rs = database.stmt.executeQuery(sql);
			while (rs.next()) {
				try {
					ProjetoUsuario ua = new ProjetoUsuario(getId(), rs.getInt(1), rs.getDate(2));
					retorno.add(ua);
				} catch (Exception e) { }
			}
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	
	public ArrayList listarUsuariosNaoAlocados() {
		
		ArrayList retorno = new ArrayList();
		
		String sql = "select u.cd_usuario "+
		"from usuario u "+
		"where u.cd_usuario not in( select cd_usuario from projeto_usuario where cd_projeto=" + getId() + " and dt_cancelamento is null )   "+
		"order by u.no_usuario";
		
		
		Database database = new Database();
		
		try {
			ResultSet rs = database.stmt.executeQuery(sql);
			
			while (rs.next()) {
				Usuario u = new Usuario();
				u.buscar(rs.getInt(1));
				retorno.add(u);
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	public void alocarUsuario(int cdUsuario, int cdAlcada) {
		
		String sql = "insert into projeto_usuario (cd_projeto, cd_usuario, cd_alcada, dt_inicio) values ("+getId()+", "+cdUsuario+", "+cdAlcada+", current_date)";
		
		Database database = new Database();
		
		try {
			database.stmt.executeUpdate(sql);
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		
	}
	
	
	public void cancelarUsuario(int cdUsuario, Date data) {
		
		Database database = new Database();
		
		try {
			String sql = "update projeto_usuario set dt_cancelamento=current_date where cd_projeto="+getId()+" and cd_usuario="+cdUsuario+" and dt_inicio='" + (new java.sql.Date(data.getTime())) + "'";
			
			//                    System.out.println(sql);
			
			database.stmt.executeUpdate(sql);
			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//erro.printStackTrace();
		}
		database.fechar();
	}
	
/* para recuperar usuario cancelado acidentalmente*/
	public void recuperarUsuario(int cdUsuario, Date data) {
		
		Database database = new Database();
		
		try {
			String sql = "update projeto_usuario set dt_cancelamento=null where cd_projeto="+getId()+" and cd_usuario="+cdUsuario+" and dt_inicio='" + (new java.sql.Date(data.getTime())) + "'";
			
			//                    System.out.println(sql);
			
			database.stmt.executeUpdate(sql);
			
		} catch (java.lang.Exception erro) {
			System.out.println(erro);
			//erro.printStackTrace();
		}
		database.fechar();
	}
/* fim*/	


	public ArrayList listarRequisitos( String trecho ) {
		
		ArrayList retorno = new ArrayList();
		
		String sql = "SELECT cd_requisito FROM requisito WHERE no_requisito LIKE '%"+trecho+"%' and cd_projeto=" + getId() + " ORDER BY no_requisito";
		
		
		Database database = new Database();
		
		try {
			ResultSet rs = database.stmt.executeQuery(sql);
			
			while (rs.next()) {
				Requisito r = new Requisito();
				r.buscar(rs.getInt(1));
				retorno.add(r);
			}
			
		} catch (java.lang.Exception erro) {
			erro.printStackTrace();
		}
		database.fechar();
		return retorno;
	}
	
	
	public String getHTMLGlossario( String texto ) {

		String retorno = texto;

		ArrayList glossarios = getGlossariosAlocados();
		
		for (int i=0; i<glossarios.size(); i++) {
			
			Glossario glossario = (Glossario)glossarios.get(i);
			retorno = glossario.marcarTermos( retorno );
		}
		return Util.replace( retorno, "\r\n", "<BR>" );
		
	
	}

	
	
	
	/**
	 * @return Returns the cancelamento.
	 */
	public Date getCancelamento() {
		return cancelamento;
	}
	/**
	 * @param cancelamento The cancelamento to set.
	 */
	public void setCancelamento(Date cancelamento) {
		this.cancelamento = cancelamento;
	}
	/**
	 * @return Returns the descricao.
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao The descricao to set.
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return Returns the glossariosAlocados.
	 */
	public ArrayList getGlossariosAlocados() {
		return glossariosAlocados;
	}
	/**
	 * @param glossariosAlocados The glossariosAlocados to set.
	 */
	public void setGlossariosAlocados(ArrayList glossariosAlocados) {
		this.glossariosAlocados = glossariosAlocados;
	}
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the idGerente.
	 */
	public int getIdGerente() {
		return idGerente;
	}
	/**
	 * @param idGerente The idGerente to set.
	 */
	public void setIdGerente(int idGerente) {
		this.idGerente = idGerente;
	}
	/**
	 * @return Returns the inicio.
	 */
	public Date getInicio() {
		return inicio;
	}
	/**
	 * @param inicio The inicio to set.
	 */
	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}
	/**
	 * @return Returns the projeto.
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param projeto The projeto to set.
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
}


