package www;

import java.sql.ResultSet;

public class Documento {

	int id = 0;
	int idTipoDocumento = 0;
	String nome="";
	String localizacao="";
	

	public String getTipoDocumento() {

		String retorno = "";
		
            Database database = new Database();
            
            try {
	    		String SQL = "select no_tipo from tipo_documento where cd_tipo_documento="+getIdTipoDocumento();

		    	ResultSet rs = database.stmt.executeQuery( SQL );
		    	
		    	if (rs.next()) 
		    		retorno = rs.getString(1);
		    	
                    
            } catch (java.lang.Exception erro) {
                    erro.printStackTrace();
            }
            
            database.fechar();
            
            return retorno;
    	
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getIdTipoDocumento() {
		return idTipoDocumento;
	}
	public void setIdTipoDocumento(int idTipoDocumento) {
		this.idTipoDocumento = idTipoDocumento;
	}
	public String getLocalizacao() {
		return localizacao;
	}
	public void setLocalizacao(String localizacao) {
		this.localizacao = localizacao;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
	
}
