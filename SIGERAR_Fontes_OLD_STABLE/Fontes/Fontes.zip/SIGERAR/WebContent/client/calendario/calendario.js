var meses = ["Janeiro","Fevereiro","Marco","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];

var iframe;
var destino;

var container;
var containerOMD;

var dataAtual;
var dataInicial;
var hoje=new Date();



function inicializar() {
	window.parent.mostraCalendario = new Object();
	window.parent.mostraCalendario.mostrar = function() {
	
	container = window.parent;

	var containerOMD=container.document.onmousedown?container.document.onmousedown:null;
	container.document.onmousedown=function(e){
	  var n=!e?container.event.srcElement:e.target;
	  
	  if (!/popcal/i.test(n.name)) fechar();
	  
	  if (containerOMD) containerOMD(e);
	}
	
	var containerOKD=container.document.onmousedown?container.document.onkeydown:null;
	container.document.onkeydown=function(e){
		var evt=e?e:container.event;
			
		if (evt.keyCode==27) 
		fechar();
		
		if (containerOKD) containerOKD(e);
	}
	
	
	destino = arguments[0];
	if (!destino.disabled)
		aparecer(window.parent.document.getElementById("calendario"), destino);
	}
	
	
}


function aparecer( pIframe, pDestino ) {

	iframe = pIframe;
	destino = pDestino;

	if (iframe.style.display=="") {
		fechar();
		return;
	}

	iframe.style.display="";
	iframe.style.top = getTopPosition(destino) + destino.offsetHeight;
	iframe.style.left = getLeftPosition(destino);

	dataEscrita = destino.value;
	
	if (isDateString(dataEscrita)) {
		dataAtual = myParseDate( dataEscrita );
	} else 
		dataAtual = new Date();
		
	dataInicial = new Date( dataAtual.getFullYear(), dataAtual.getMonth(), dataAtual.getDate() );
	
	desenhaCalendario();

	
}

function fechar() {
	iframe.style.display="none";
}

function getTopPosition( objeto ) {
	if (objeto.offsetParent!=null)
		return objeto.offsetTop + getTopPosition( objeto.offsetParent );
	else 
		return objeto.offsetTop;
}

function getLeftPosition( objeto ) {
	if (objeto.offsetParent!=null)
		return objeto.offsetLeft + getLeftPosition( objeto.offsetParent );
	else 
		return objeto.offsetLeft;
}


function getYear(d) { 
	return (d < 1000) ? d + 1900 : d;
}


function myIsDate (year, month, day) {
  // month argument must be in the range 1 - 12
  month = month - 1;  // javascript month range : 0- 11
  var tempDate = new Date(year,month,day);
  
  if ( (getYear(tempDate.getYear()) == year) &&
     (month == tempDate.getMonth()) &&
     (day == tempDate.getDate()) ) {
	      return true;
  } else {
  	return false
  }
}


function isDateString (str) {
	iDia = parseInt( str.substring(0,2), 10 );
	iMes = parseInt( str.substring(3,5), 10 );
	iAno = parseInt( str.substring(6,10), 10 );

	return myIsDate( iAno, iMes, iDia);
	
}






function myParseDate (str) {
	iDia = parseInt( str.substring(0,2), 10 );
	iMes = parseInt( str.substring(3,5), 10 );
	iAno = parseInt( str.substring(6,10), 10 );

	iMes = iMes - 1;  // javascript month range : 0- 11
	
	return new Date(iAno,iMes,iDia);
}







function desenhaCalendario() {
	document.getElementById("mes").innerHTML=meses[ dataAtual.getMonth() ] + "/" + dataAtual.getFullYear();

	d = new Date(dataAtual.getFullYear(), dataAtual.getMonth(), dataAtual.getDate()  );
	d.setDate(1);

	while(d.getDay()>0) {
		d.setDate( d.getDate()-1 );
	}

	document.getElementById( "penultimaSemana" ).style.display="";
	document.getElementById( "ultimaSemana" ).style.display="";

	for (i=0; i<6; i++) {

		for (j=0; j<7; j++) {

			celula=document.getElementById( "d"+i+"-"+d.getDay() );
			
			if (i==4 && j==0 && d.getMonth()!=dataAtual.getMonth()) {
				document.getElementById( "penultimaSemana" ).style.display="none";
				document.getElementById( "ultimaSemana" ).style.display="none";
				break;
			}

			if (i==5 && j==0 && d.getMonth()!=dataAtual.getMonth()) {
				document.getElementById( "ultimaSemana" ).style.display="none";
				break;
			}

			fimdesemana=false;
			if (d.getDay()==0 || d.getDay()==6) {
				fimdesemana=true;
			}

			if (d.getMonth()!=dataAtual.getMonth()) {
				celula.attributes["class"].value="outroMes";
				celula.innerHTML=
				"<span " + (fimdesemana?"class='fimdesemana'":"") + ">"+d.getDate()+"</span>";
			} else {
				celula.attributes["class"].value="esteMes";
				celula.innerHTML=
				"<a href=\"javascript:escolher('" + formatar(d) + "')\" " + (fimdesemana?"class='fimdesemana'":"") + ">"+d.getDate()+"</a>";
			}

			if (formatar(d)==formatar(dataInicial)) {
				celula.attributes["class"].value=celula.attributes["class"].value+"Atual";
			} else if (formatar(d)==formatar(hoje)) {
				celula.attributes["class"].value=celula.attributes["class"].value+"Hoje";
			}

			d.setDate( d.getDate()+1 );
		}
		
	}
	
	iframe.style.width = document.getElementById("calendario").offsetWidth;
	iframe.style.height = document.getElementById("calendario").offsetHeight;
}


function proximo() {
	dataAtual.setDate( 1 );
	dataAtual.setMonth( dataAtual.getMonth()+1 );
	desenhaCalendario();
}


function anterior() {
	dataAtual.setDate( 1 );
	dataAtual.setMonth( dataAtual.getMonth()-1 );
	desenhaCalendario();
}


function formatar( data ) {
	formatado = String((data.getFullYear() * 100 + data.getMonth() + 1) * 100 + data.getDate());
	formatado = formatado.substring(6,8)+ "/" + formatado.substring(4,6)+ "/" + formatado.substring(0,4);
	return formatado;
}




function escolher(valor) {
	destino.value = valor;
	if (destino.onchange!=null) destino.onchange();
	fechar();
}


function keypressed(e) {
	
	if (!e) e=window.event;

	if (e.keyCode==27) fechar();

}


